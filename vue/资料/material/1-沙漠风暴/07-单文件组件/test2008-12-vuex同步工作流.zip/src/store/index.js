import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  // state公共状态
  state: {
    cityId: '310100',
    cityName: '上海'
  },
  // 统一管理， 被devtools 记录状态的修改
  mutations: {
    changeCityName (state, cityName) {
      state.cityName = cityName
      // console.log(cityName)
    }
  }
})
