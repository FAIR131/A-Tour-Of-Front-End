<template>
    <div class="swiper-container kerwin">
        <div class="swiper-wrapper">
          <slot></slot>
        </div>
    </div>
</template>

<script>
import Swiper from 'swiper/bundle'
import 'swiper/swiper-bundle.css'
export default {
  props: {
  },
  mounted () {
    // console.log("mounted")
    new Swiper('.kerwin', {
      slidesPerView: 3.5,
      spaceBetween: 30,
      freeMode: true

    })
  }
}
</script>
