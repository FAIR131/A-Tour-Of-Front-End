<template>
    <div>
        detail
    </div>
</template>
<script>
export default {
  created () {
    // 当前匹配的路由
    console.log('created', this.$route.params.id)

    // axios 利用 id 发请求到详情接口 ，获取详细数据 ，布局页面
  }
}
</script>
