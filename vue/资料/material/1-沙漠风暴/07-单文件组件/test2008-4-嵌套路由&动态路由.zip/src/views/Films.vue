<template>
    <div>
        <div style="height:200px;background:yellow;">大轮播</div>

        <div>
            二级的声明式导航
        </div>

        <router-view></router-view>
    </div>
</template>
