<template>
    <div>
        nowplaying
        <ul>
            <li v-for="data in datalist" :key="data" @click="handleChangePage(data)">
                {{data}}
            </li>
        </ul>
    </div>
</template>
<script>
export default {
  data () {
    return {
      datalist: ['1111', '2222', '3333']
    }
  },

  methods: {
    handleChangePage (id) {
    //   console.log(id)
      // 编程式导航
      //   location.href = '#/detail'

      // /detail/1111
      this.$router.push(`/detail/${id}`)
    }
  }
}
</script>
