// vue项目的配置文件 覆盖，

module.exports = {
  lintOnSave: false // 暂时关闭代码格式检测
}
