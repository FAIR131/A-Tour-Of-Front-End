<template>
  <div>
    <ul>
      <!-- vue-router(3之前，包括3) -1- 声明式导航 -->

        <!-- <router-link to="/films" active-class="kerwinactive" tag="li">电影</router-link>

        <router-link to="/cinemas" active-class="kerwinactive" tag="li">影院</router-link> -->

        <!-- vue-router（4） -2- 声明式导航 -->

         <router-link to="/films" custom v-slot="{navigate,isActive}">
            <li @click="navigate" :class="isActive?'kerwinactive':''">电影</li>
         </router-link>
        <router-link to="/cinemas" custom v-slot="{navigate,isActive}">
           <li @click="navigate" :class="isActive?'kerwinactive':''">影院</li>
        </router-link>
         <router-link to="/center" custom v-slot="{navigate,isActive}">
           <li @click="navigate" :class="isActive?'kerwinactive':''">我的</li>
        </router-link>
    </ul>

    <!-- 路由容器 -->
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  data () {
    return {

    }
  }
}
</script>
<style lang="scss">
*{
  margin:0;
  padding: 0;
}
.kerwinactive{
  color:red;
}
</style>
