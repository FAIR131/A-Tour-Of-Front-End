<template>
    <div>
        cinemas
    </div>
</template>
