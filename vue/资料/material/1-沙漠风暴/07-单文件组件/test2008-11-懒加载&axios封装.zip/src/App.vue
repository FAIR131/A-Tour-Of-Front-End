<template>
  <div>
    <tabbar ref="mytabbar"></tabbar>
    <!-- 路由容器 -->
    <section>
      <router-view></router-view>
    </section>
  </div>
</template>
<script>
import Vue from 'vue'
import Vant from 'vant'
import 'vant/lib/index.css'
import tabbar from '@/mycomponents/Tabbar'

Vue.use(Vant) // Vue.component(全局定义组件)
export default {
  data () {
    return {

    }
  },
  mounted () {
    // console.log(this.$refs.mytabbar.$el.offsetHeight)
  },
  components: {
    tabbar
  }
}
</script>
<style lang="scss">
*{
  margin:0;
  padding: 0;
}
html,body{
  height: 100%;
}
ul{
  list-style: none;
}
section{
  padding-bottom: 2.722222rem;
}
</style>
