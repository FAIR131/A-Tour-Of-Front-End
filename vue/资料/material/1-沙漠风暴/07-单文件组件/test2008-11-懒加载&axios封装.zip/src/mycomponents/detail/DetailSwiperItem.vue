<template>
     <div class="swiper-slide">
        <slot></slot>
      </div>
</template>
