<template>
  <div>
    <van-index-bar>
      <van-index-anchor index="A" />
      <van-cell title="A1" />
      <van-cell title="A2" />
      <van-cell title="A3" />

      <van-index-anchor index="B" />
      <van-cell title="B1" />
      <van-cell title="B2" />
      <van-cell title="B3" />
    </van-index-bar>
  </div>
</template>
<script>
import http from '@/util/http'
export default {
  mounted () {
    http({
      url: '/gateway?k=5066709',
      headers: {
        'X-Host': 'mall.film-ticket.city.list'
      }
    }).then(res => {
      console.log(res.data.data.cities)

      // 1， 316条 ==> A ,B进行分组
      // 2.  利用转换后的数组，结合组件库进行渲染页面。
    })
  }
}
</script>
