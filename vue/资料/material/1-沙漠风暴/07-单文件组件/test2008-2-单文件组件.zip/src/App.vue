<template>
  <div>
    hello appp-{{myname}}
    <!-- <img src="/demo.gif"/> -->
    <input type="text" v-model="mytext"/>
    <button @click="handleAdd">add</button>
    <ul>
      <li v-for="data in datalist" :key="data">
        {{data}}
      </li>
    </ul>

    <navbar myname="home" :myright="false" @event="handleEvent">
      <div>22222222</div>
    </navbar>

    <sidebar v-show="isShow"></sidebar>

    <div v-hello>111111111111111111</div>
    <div v-hello>222222222222222222</div>

    <img :src="imgUrl | imgFilter"/>
  </div>
</template>
<script>
// ES6 导出规范 -babel(ES6==>ES5)
// @ 别名===> src的绝对路径
import navbar from '@/mycomponents/Navbar' // webpack 配置的别名。
import sidebar from '@/mycomponents/Sidebar'
import Vue from 'vue'
import axios from 'axios'
// 全局或则 局部注册的
// Vue.component('navbar', navbar)
Vue.directive('hello', {
  inserted (el, binding) {
    // console.log(el)
    el.style.border = '1px solid black'
  }
})
Vue.filter('imgFilter', (path) => {
  return path.replace('/w.h', '') + '@1l_1e_1c_128w_180h'
})
export default {
  data () {
    return {
      myname: 'kerwin111',
      mytext: '',
      datalist: [],
      isShow: true,
      imgUrl: 'http://p0.meituan.net/w.h/movie/056d4f1a658e3e35c9f9e6c44c2aa3fe1831930.jpg'

    }
  },
  components: {
    navbar,
    sidebar
  }, // 局部注册
  methods: {
    handleAdd () {
      console.log(this.mytext)
      this.datalist.push(this.mytext)
    },
    handleEvent () {
      this.isShow = !this.isShow
    }
  },
  computed: {

  },
  watch: {

  },
  mounted () {
    axios.get('/kerwin/ajax/movieOnInfoList?token=&optimus_uuid=74B5F0A032A711EB82DD6B9282E93C676D27D7B9731D4E608D7612C3E708C120&optimus_risk_level=71&optimus_code=10').then(res => {
      console.log(res.data)
    })
  }
}
</script>
<style lang="scss">
  $width:300px;
  ul{
     li {
      background:yellow;
      width:$width;
    }
  }
</style>
