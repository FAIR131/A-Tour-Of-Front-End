<template>
  <div>
    <ul>
      <li>
        <a href="/#/films">电影</a>
      </li>
       <li>
        <a href="/#/cinemas">影院</a>
      </li>
       <li>
        <a href="/#/center">我的</a>
      </li>
    </ul>

    <!-- 路由容器 -->
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  data () {
    return {

    }
  }
}
</script>
<style lang="scss">

</style>
