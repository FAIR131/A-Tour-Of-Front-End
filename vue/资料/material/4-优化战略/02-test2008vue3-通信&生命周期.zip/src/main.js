import { createApp } from 'vue'
import App from './base/07-lifecycle.vue'
import router from './router'
import store from './store'

import Vant from 'vant';
import 'vant/lib/index.css';

createApp(App)
    .use(router)
    .use(store)
    .use(Vant)
    .mount('#app')
//Vue.createApp