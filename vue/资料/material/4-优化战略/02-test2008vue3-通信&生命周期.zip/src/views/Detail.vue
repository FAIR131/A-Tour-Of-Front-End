<template>
    <div>
        detail
    </div>
</template>

<script>
export default {
    mounted(){
        this.$store.commit("hide")
        console.log(this.$route.params.id)

    },
    beforeUnmount(){
        console.log("beforeUnmount")
    },
    unmounted(){
        this.$store.commit("show")
    }
}
</script>