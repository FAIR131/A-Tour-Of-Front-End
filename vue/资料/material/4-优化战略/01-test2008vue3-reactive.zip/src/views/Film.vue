<template>
    <div>
        <div>大轮播</div>
        <router-view></router-view>
    </div>
</template>