<template>
  <div>
    nowplaying

    <ul>
      <li
        v-for="data in datalist"
        :key="data.filmId"
        @click="handleChangePage(data.filmId)"
      >
        {{ data.name }}

        <div>{{ actorFilter(data.actors) }}</div>
      </li>
    </ul>
  </div>
</template>

<script>
import axios from "axios";
export default {
  data() {
    return {
      datalist: [],
    };
  },
  mounted() {
    axios({
      url:
        "https://m.maizuo.com/gateway?cityId=440300&pageNum=1&pageSize=10&type=1&k=9316744",
      headers: {
        "X-Client-Info":
          '{"a":"3000","ch":"1002","v":"5.0.4","e":"1606697250632532718583809"}',
        "X-Host": "mall.film-ticket.film.list",
      },
    }).then((res) => {
      this.datalist = res.data.data.films;
    });
  },
  methods: {
    handleChangePage(id) {
      this.$router.push(`/detail/${id}`);
    },
    actorFilter(data) {
      if (data === undefined) return "暂无主演";
      return data.map((item) => item.name).join(" ");
    },
  },
};
</script>