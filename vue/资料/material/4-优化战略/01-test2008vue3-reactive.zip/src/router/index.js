import { createRouter, createWebHashHistory } from 'vue-router'
import Film from '../views/Film.vue'
import Nowplaying from '../views/films/Nowplaying.vue'
import Comingsoon from '../views/films/Comingsoon.vue'
import Cinema from '../views/Cinema.vue'
import Detail from '../views/Detail.vue'
import Center from '../views/Center.vue'
const routes = [
  {
    path: '/films',
    component: Film,
    name: 'film',
    children: [
      {
        path: '/films/nowplaying',
        component: Nowplaying
      },
      {
        path: '/films/comingsoon',
        component: Comingsoon
      },
      {
        path: '/films',
        redirect: '/films/nowplaying'
      }
    ]
  },
  {
    path: '/cinemas',
    component: Cinema
  },
  {
    path: '/detail/:id',
    component: Detail
  },
  {
    path: '/center',
    component: Center
  },
  {
    path: '/',
    redirect: '/films'
  },
  {
    path: '/:anywadadaddada',
    redirect: {
      name: 'film'
    }
  }
]

const router = createRouter({
  // history: createWebHistory(),// history 模式
  history: createWebHashHistory(), //hash 模式
  routes
})
// router.beforeEach
export default router
