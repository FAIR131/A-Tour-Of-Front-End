import { createApp } from 'vue'
import App from './base/02-todo.vue'
import router from './router'
import store from './store'

import Vant from 'vant';
import 'vant/lib/index.css';

createApp(App)
    .use(router)
    .use(store)
    .use(Vant)
    .mount('#app')
//Vue.createApp