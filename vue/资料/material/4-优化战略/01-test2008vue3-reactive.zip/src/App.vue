<template>
  <div>
    <ul v-show="$store.state.isTabbarShow">
      <router-link to="/films" custom v-slot="{ navigate, isActive }">
        <li @click="navigate" :class="isActive ? 'kerwinactive' : ''">
          <i class="iconfont icon-all"></i>
          <span>电影</span>
        </li>
      </router-link>
        <router-link to="/cinemas" custom v-slot="{ navigate, isActive }">
        <li @click="navigate" :class="isActive ? 'kerwinactive' : ''">
          <i class="iconfont icon-all"></i>
          <span>影院</span>
        </li>
      </router-link>
        <router-link to="/center" custom v-slot="{ navigate, isActive }">
        <li @click="navigate" :class="isActive ? 'kerwinactive' : ''">
          <i class="iconfont icon-all"></i>
          <span>我的</span>
        </li>
      </router-link>
    </ul>
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  data(){
    return {
      mytext:''
    }
  },
  components:{
    
  },
  //局部指令
  directives:{
    hello:{
      mounted(){
        console.log("moutend")
      }
    }
  }
}
</script>

<style lang="scss" scoped> 
.kerwinactive{
  color:red;
}
</style>