<template>
  <div>
    nowplaying

    <ul>
      <li
        v-for="data in datalist"
        :key="data.filmId"
        @click="handleChangePage(data.filmId)"
      >
        {{ data.name }}

        <div>{{ actorFilter(data.actors) }}</div>
      </li>
    </ul>
  </div>
</template>

<script>
import axios from "axios";
import { onMounted, reactive,toRefs } from 'vue';
import {useRouter} from 'vue-router'
export default {

  setup(){

    const router = useRouter() // router === this.$router
    const obj = reactive({
      datalist:[]
    })

    const handleChangePage = (id)=>{
      // console.log()
      router.push(`/detail/${id}`)
    }

    const actorFilter = (data) =>{
      if (data === undefined) return "暂无主演";
      return data.map((item) => item.name).join(" ");
    }

    onMounted(()=>{
      axios({
            url:
              "https://m.maizuo.com/gateway?cityId=440300&pageNum=1&pageSize=10&type=1&k=9316744",
            headers: {
              "X-Client-Info":
                '{"a":"3000","ch":"1002","v":"5.0.4","e":"1606697250632532718583809"}',
              "X-Host": "mall.film-ticket.film.list",
            },
          }).then((res) => {
            obj.datalist = res.data.data.films;
      });
    })

    return {
      ...toRefs(obj),
      handleChangePage,
      actorFilter
    }
  }
};
</script>