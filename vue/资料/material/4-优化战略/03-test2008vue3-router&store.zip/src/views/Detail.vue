<template>
    <div>
        detail
    </div>
</template>

<script>
import { inject, onMounted, onUnmounted } from 'vue'
import {useRoute} from 'vue-router'
import {useStore} from 'vuex'
export default {
    // mounted(){
    //     this.$store.commit("hide")
    //     console.log(this.$route.params.id)

    // },
    // beforeUnmount(){
    //     console.log("beforeUnmount")
    // },
    // unmounted(){
    //     this.$store.commit("show")
    // }

    setup(){
        const route = useRoute()  // route === this.$route
        const store = useStore() // store === this.$store
        
        const isShow = inject("kerwinshow")
        onMounted(()=>{
            store.commit("hide")
            console.log(route.params.id)    
            
            isShow.value = false
        })

        onUnmounted(()=>{
            store.commit("show")

            isShow.value = true
        })
    }
}
</script>