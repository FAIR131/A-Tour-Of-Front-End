const nodemailer = require('nodemailer');
const conf = require("../config").SMTP;

let smtp = (function(){
    class SendMail{
        constructor() {
            this.transporter = nodemailer.createTransport(conf);
        }
        //发送
        send(to,code,callback){
            let mailOptions = {
                from:conf.auth.user, //发送者邮箱
                to:to, //接受者邮箱,可以设置多个"123@qq.com,321@126.com"
                subject:'【仁雨科技】验证码', //邮件主题
                text:'【仁雨科技】验证码', //信箱里邮件列表时，此邮件显示的内容说明
                html:`<h1>【仁雨科技】验证码为<font color="red">${code}</font>,有效时间为10分钟,请尽快验证.</h1>`, //邮件内容

                // watchHtml: '<b>企业</b> 培训证书！', // Apple Watch specific HTML body 苹果手表指定HTML格式

                //附件 filename在邮件中附件显示的名字，content附件的内容，contentType附件的类型，cid附件的id
                //关于附件的更多用法以及属性说明，参考 https://nodemailer.com/message/attachments/
                // attachments: [
                //     // String attachment
                //     {
                //         filename: 'notes.txt',
                //         content: 'Some notes about this e-mail',
                //         contentType: 'text/plain' // 可选，会检测文件名
                //     },
                //     // Binary Buffer attchment
                //
                //     // // File Stream attachment
                //     {
                //         filename: 't2.jpg',
                //         path: __dirname + '/config.js',
                //         cid: '00002'  // id唯一
                //     }
                // ]
            };

            this.transporter.sendMail(mailOptions,(err,info)=>{
                callback(err,info);
            });
        }
    }

    return new SendMail();
})()

module.exports = smtp;

