const fs = require("fs");

class UploadTools{
    constructor(path) {
        this.path = path;
    }
    //判断当前路径存不存在
    has(){
        return fs.existsSync(this.path);
    }
    //创建一个目录
    create(){
        let mkdir_status = false;
        try{
            fs.mkdirSync(this.path);
            mkdir_status = true;
        }catch (error){
            console.log(error);
        }
        return mkdir_status;
    }
    //读取文件夹,返回是一个数组['1.txt']
    ischild(){
        let childs = fs.readdirSync(this.path);
        return childs.length ? childs[0] : false;
    }
    //删除指定路径
    remove(path){
        let res = false;
        try{
            fs.unlinkSync(path);
            res = true;
        }catch(error){
            console.log(error);
        }
        return res;
    }
    //保存
    save(path,data){
        let res = false
        try{
            //文件内容
            let body = fs.readFileSync(data);
            fs.writeFileSync(path,body);
            res = true;
        }catch (error){
            console.log(error);
        }
        return res
    }
}

module.exports = UploadTools;