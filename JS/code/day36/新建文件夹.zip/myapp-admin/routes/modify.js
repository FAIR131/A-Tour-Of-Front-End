const express = require("express");
const router = express.Router();
const mysql = require("../tools/mysqlTool");
const smtp = require("../tools/smtpTool");
const Redis = require("../tools/redisTool");
const redis_conf = require("../config").REDIS;
const upload = require("../tools/uploadTool");
const images = require("images");
const path = require("path");


//修改信息
router.post("/modinfo",(req,res)=>{
    //普通的数据
    let {jwt,userid,email,nick} = req.fields;
    let file = req.files;

    //拼接图片保存位置
    let abs_path = __dirname;
    abs_path = abs_path.replaceAll("\\","/");
    abs_path = abs_path.substr(0,abs_path.lastIndexOf("/"));
    abs_path = path.join(abs_path,"public/images/userimg")

    //每个用户的头像应当保存在自己的目录当中
    let user_dir = path.join(abs_path,email);

    //检测user_dir存不存在
    let uploadObj = new upload(user_dir);

    if(!uploadObj.has()){//false
        if(uploadObj.create()){
            let upload_path = path.join(user_dir,file.avatar.name);
            let show_path = "http://localhost/image/getimg/userimg/"+`${email}/${file.avatar.name}`;

            try{ images(file.avatar.path).save(upload_path);
            }catch (e) {}
            //mysql更新数据

            let sql = `update BUYR_USER set AVATAR="${show_path}",USER_NAME='${email}',NICK_NAME='${nick}' where USER_ID=${userid}`;
            try{
                mysql.query(sql,(err,result)=>{
                    if(err) throw err;
                    //替换redis当中的信息
                    let redisObj = new Redis(redis_conf.valimall);
                    let data = JSON.stringify([{USER_ID:userid,USER_NAME:email,NICK_NAME:nick,AVATAR:show_path}]);
                    redisObj.set(jwt,data,60*120);
                    res.json({code:1,msg:"修改成功",userinfo:data});
                    redisObj.quit();
                });
            }catch (e) {
                res.json({code:0,msg:"上传失败"});
                //刚刚上传的图片应当删除
                uploadObj.remove(upload_path);
            }

        }else{
            res.json({code:0,msg:"上传失败"});
        }
    }else{
        //文件已存在,那么一定包含子文件
        let redisObj = new Redis(redis_conf.valimall);
        //jwt是redis当中存储用户信息的key
        redisObj.get(jwt,(err,data)=>{
            //获取以前的头像路径
            let old_ava = JSON.parse(data)[0].AVATAR.replaceAll("\\","/");

            old_ava = path.join(user_dir,old_ava.substr(old_ava.lastIndexOf("/")));

            let show_path = "http://localhost/image/getimg/userimg/"+`${email}/${file.avatar.name}`;
            try{
                let sign = uploadObj.remove(old_ava);
                if(sign){
                    let new_ava = path.join(user_dir,file.avatar.name);

                    try{ images(file.avatar.path).save(new_ava);
                    }catch (e) {}

                    let sql = `update BUYR_USER set AVATAR="${show_path}",USER_NAME='${email}',NICK_NAME='${nick}' where USER_ID=${userid}`;
                    try{
                        mysql.query(sql,(err,result)=>{
                            if(err) throw err;
                            //替换redis当中的信息
                            let redisObj = new Redis(redis_conf.valimall);
                            let data = JSON.stringify([{USER_ID:userid,USER_NAME:email,NICK_NAME:nick,AVATAR:show_path}]);
                            redisObj.set(jwt,data,60*120);
                            res.json({code:1,msg:"修改成功",userinfo:data});
                            redisObj.quit();
                        });
                    }catch (e) {
                        res.json({code:0,msg:"上传失败"});
                        //刚刚上传的图片应当删除
                        uploadObj.remove(old_ava);
                    }
                }else{
                    res.json({code:0,msg:"上传失败"});
                }
            }catch (e){}


        })
    }
})


module.exports = router;


