var express = require('express');
var router = express.Router();
const Redis = require("../tools/redisTool");
const redis_conf = require("../config").REDIS;

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

//获取用户信息
router.post('/getuser', function(req, res, next) {
  let {token} = req.body;

  let redisObj = new Redis(redis_conf.valimall);

  try{
    redisObj.get(token,(err,result)=>{
      if(err) throw err;
      res.json({code:1,msg:"成功",info:JSON.parse(result)[0]});
    });
  }catch(e){
    res.json({code:0,msg:"发生了无法预知的错误!"})
  }
});


module.exports = router;
