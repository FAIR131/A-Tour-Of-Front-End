const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const sess = require("express-session");
const redis = require("./tools/redisTool");
const RedisStore = require("connect-redis")(sess);
const config = require("./config").REDIS.valicode;
const cors = require("cors");
const formidable = require("express-formidable");

//redis的实例化
const redisClient = new redis(config);

const indexRouter = require('./routes/index');
const usersRouter = require('./routes/users');
const imageRouter = require('./routes/images');
const modiRouter = require('./routes/modify');
const app = express();


//配置sess
app.use(sess(sess_option = {
  //sess自动存储到redis缓存当中
  store : new RedisStore({client : redisClient}),
  //默认的sess头名称
  name : "web2211",
  //sess+login_status,进行加密
  secret : "login_status",
  resave : true,
  saveUninitialized : true,
  cookie : {
    //sess  和 cookie 的有效存储时间
    maxAge : 10 * 60 * 1000,
    httpOnly : false ,   //js能控制cookie
    secure : false ,
    rolling : true ,
  }
}));

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));

app.use(express.json());

app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

//
app.use(cors({
  origin:['http://localhost:8080' , 'http://127.0.0.1:8080'],
  methods:['GET','POST'],
  alloweHeaders:['Content-Type', 'Authorization'],
  credentials:true,
}));




app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/image',imageRouter);

//解析formdata对象,必须放在路由之前
app.use(formidable());
app.use("/modi",modiRouter);



// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
