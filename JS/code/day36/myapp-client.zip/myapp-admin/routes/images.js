const express = require("express");
const router = express.Router();
const bpath = require("path");

//任意子路由 : 拼接上public/images/任意文件夹
router.get("/getimg/*",(req,res)=>{
    //去除自定义路由,获取文件夹路径
    let path = req.url.replaceAll("\\","/").substr(1);
    path = path.substr(path.indexOf("/"));

    //获取当前路径
    let abs_path = __dirname;
    abs_path = abs_path.replaceAll("\\","/");
    //去除/routes
    abs_path = abs_path.substr(0,abs_path.lastIndexOf("/"));

    //拼接图片的路径
    //public/images是固定路径
    abs_path = bpath.join(abs_path,"public/images");

    //拼接动态路径
    abs_path = bpath.join(abs_path,path);

    res.sendFile(abs_path);
})

//导出路由
module.exports = router;