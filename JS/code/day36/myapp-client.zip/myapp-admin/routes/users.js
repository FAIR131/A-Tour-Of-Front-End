const express = require('express');
const router = express.Router();
const mysql = require("../tools/mysqlTool");
const smtp = require("../tools/smtpTool");
const Redis = require("../tools/redisTool");
const redis_conf = require("../config").REDIS;
const svgCaptcha = require("svg-captcha");
const sha256 = require("sha256");
const ns = require("../config").NumSign;
const jwt = require("jsonwebtoken");

/* 注册API*/
router.post('/signup', function(req, res, next) {
  /*
  *   1.接受前端发送的body数据
  *   2.验证当前的账号在不在数据库当中
  *     - 1).不在,则代表没注册过,则插入数据(返回的数据长度为0)
  *     - 2).在,代表已经被注册过了,返回提示信息
  * */
  let {username,password,valicode} = req.body;
  //密码盐 -> 由前端的加密密码 + 数字签名
  let avatar = "http://localhost/image/getimg/userimg/default/default.jpg";
  let password_salt = sha256(password,ns);

  let sql1 = `select \`USER_NAME\` from \`BUYR_USER\` where  \`USER_NAME\`='${username}'`;
  let sql2 = `insert into \`BUYR_USER\` set \`USER_NAME\`='${username}',\`PASS_SALT\`='${password_salt}',AVATAR='${avatar}',NICK_NAME='空气'`;

  //验证码验证
  let redisObj = new Redis(redis_conf.valimall);
  //获取到redis当中的邮箱对应值
  new Promise((resolve, reject)=>{
    redisObj.get(username,function(error,result){
      if(error) throw error;
      //比对ajax传过来的验证码 和 redis数据库当中的验证码是否一致
      resolve(result);
    });
  }).then(value=>{
    if(valicode === value){ //验证码正确
      new Promise((resolve, reject)=>{
        mysql.query(sql1,(error,result)=>{ //查询用户名在不在数据库当中
          if(error) throw error
          resolve(result);
        })
      }).then(value=>{
        if(value.length===0){
          mysql.query(sql2,(error,result)=>{//插入数据
            if(error) throw error
            //注册成功以后销毁验证码
            redisObj.delete(username);
            redisObj.quit();//redis断开连接
            res.json({code:1,msg:`注册成功!`})
          })
        }else{//用户名已经被注册
          redisObj.quit();//redis断开连接
          res.json({code:0,msg:`${username}已经注册!`})
        }

      })
    }else{//验证码不对
      res.json({code:0,msg:`验证码不正确!`});

    }
  })

});

//发送邮件
router.post("/sendmail",(req,res)=>{
  /*
  * body ; email_address
  * */
  let {username} = req.body;
  let valicode = String(Math.random()*10000000000000).substr(0,4);
  smtp.send(username,valicode,function(error,info){
    if(error){
      res.json({code:500,msg:"邮件发送失败"});
    }else{
      let redisObj = new Redis(redis_conf.valimall);
      try{
        //把当前的邮箱和验证码发到redis缓存当中
        redisObj.set(username,valicode,600);

        res.json({code:200,msg:"邮件发送成功"});
      }catch (e) {

      }finally {
        redisObj.quit();
      }

    }
  });
})

//将有问题的代码抽离出来
//使用ApiFox
/*router.post("/error",(req,res)=>{
  let {username} = req.body;
  let redisObj = new Redis(redis_conf.valimall);
  redisObj.delete(username);
  res.send("ok")
})*/

//验证用户存不存在
router.get("/valiuser",(req,res)=>{
  let {username} = req.query;
  let sql1 = `select \`USER_NAME\` from \`BUYR_USER\` where  \`USER_NAME\`='${username}'`;
  mysql.query(sql1,(error,result)=>{ //查询用户名在不在数据库当中
    if(error) throw error
    if(result.length === 0){//没人注册过
      res.json({code:1,msg:"当前账号可以使用"});
    }else{//有人注册过
      res.json({code:0,msg:"当前账号已被注册"});
    }
  })
})

router.get('/captcha', function (req, res) {
  var codeConfig = {
    size: 4,// 验证码长度
    ignoreChars: '0o1i', // 验证码字符中排除 0o1i
    noise: 6, // 干扰线条的数量
    height: 40,
    inverse: false,
    fontSize: 40,
  }
  //验证码实例 : 验证码
  var captcha = svgCaptcha.create(codeConfig);
  res.setHeader('Content-Type', 'image/svg+xml');
  //每次刷新的时候,把验证码保存到redis当中,使用session当做key
  let key = req.sessionID;
  let val = captcha.text.toLowerCase();
  let redisObj = new Redis(redis_conf.valimall);
  redisObj.set(key,val,10*60);
  redisObj.quit();
  res.type('svg');
  res.status(200).send(captcha.data);
});

//登录业务
router.post("/signin",(req,res)=>{
  let {username,password,valicode,sesskey} = req.body;
  //""  ''  --  #

  let password_salt = sha256(password,ns);
  let redisObj = new Redis(redis_conf.valimall);
  new Promise((resolve, reject) => {
    redisObj.get(sesskey,function(err,result){
      if(err) throw err;
      resolve(result);
    })

  }).then(value=>{
    if(valicode.toLowerCase() === value){//验证码正确
      let sql1 = `select USER_ID,USER_NAME,NICK_NAME,AVATAR from \`BUYR_USER\` where  \`USER_NAME\`='${username}' and \`PASS_SALT\`='${password_salt}'`;

      mysql.query(sql1,function(error,result){
        if(error) throw error;
        if(result.length === 0){//账户或密码错误
          res.json({code:0,msg:"账户或密码错误"});
        }else{//正确
          // console.log(result);
          //用jwt作为redis的key
          let key = jwt.sign(username,ns);
          let val = JSON.stringify(result);
          //存储时间2H
          redisObj.set(key,val,120 * 60);
          redisObj.quit();
          res.json({code:1,msg:"登录成功",token:key});
        }
      })
    }else{//验证码不正确
      res.json({code:0,msg:"验证码不正确"});
    }

  }).catch(reason=>{
    redisObj.quit();
  })

})
module.exports = router;