

//MySQL Connect(连接) Model(模型)
//工厂模式 策略模式  单例模式
//单例模式 : 不管实例化多少次,实例对象只有一个
let mysql = (function (){
    class MCM{
        //静态属性只有一个
        static instance = null;
        constructor() {
            if(!MCM.instance){
                //引入mysql的配置
                this.config = require("../config").MySQL;
                //安装mysql组件
                //cnpm i mysql
                this.mysql = require("mysql");
                //如果instance为null,则自己返回自己
                MCM.instance = this;
            }
            return MCM.instance
        }

        //执行sql语句的部分
        //dual是mysql的关键字(虚拟表)
        query(sql="select 'no sql' from dual",callback){
            //连接数据库对象
            //create(创建)  Connection(链接)
            let conn = this.mysql.createConnection(this.config);

            //数据连接:查询或插入或修改
            conn.connect(err=>{
                if(err) throw err;
                console.log("mysql connection success!")
            });

            //执行语句
            //result : 结果
            conn.query(sql,(err,result)=>{
                callback(err,result);
            })

            //使用完断开连接
            conn.end(err=>{
                if(err) throw err;
                console.log("mysql connection quit!")
            });
        }
    }

    return new MCM();
})()

module.exports = mysql;



