const redis = require('redis');//引入库

class RedisModel{
    //redis要不要写成单例模式
    //不要 :
    // 邮箱验证码  手机验证码   记录登陆信息
    constructor(redis_conf) {
        this.client = redis.createClient(redis_conf);//创建redis终端
        this.client.on('error', err => {//错误触发事件
            console.log(err)
        })
    }
    quit() {
        //断开链接
        this.client.quit()
    }
    //添加数据
    set(key, value, time) {
        //判断value值是否是对象类型
        if (typeof value === 'object') {
            value = JSON.stringify(value);
        }
        //time为过期时间，可选
        if(time){
            this.client.set(key, value);
            this.client.expire(key,time);
        }else{
            this.client.set(key, value); //如果不写time则永久保存
        }

        return `${key} insert success`;
    }
    //获取数据
    get(key,callback) {
        this.client.get(key,(err,result)=>{
            callback(err,result);
        });
    }

    //删除数据
    delete(key) {
        console.log(1234);
        this.client.del(key);
    }
}



module.exports = RedisModel;