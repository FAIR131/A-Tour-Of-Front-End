const MySQL = {
    host : "122.112.145.18",
    user : "hal",
    password : "123456",
    port : "3306",
    database : "myapp",
}
//邮件发送的配置
const SMTP = {
    host : "smtp.163.com",
    port : "25",
    auth : {
        user : "halrui@163.com",
        pass : "PHHSMSAFITPIGIBO"
    }
}

//redis的配置项
const  REDIS ={
    //邮箱注册 保存验证码
    valimall : {
        host : "122.112.145.18",
        prot : "6379",
        auth_pass : "123456",
        db : 0
    },
    valicode : {
        host : "122.112.145.18",
        prot : "6379",
        auth_pass : "123456",
        db : 1
    },

}

//当前项目的端口号
const MyAPP = {
    port : 80,
}

const NumSign = "web2211";


module.exports = {MySQL,SMTP,REDIS,MyAPP,NumSign};