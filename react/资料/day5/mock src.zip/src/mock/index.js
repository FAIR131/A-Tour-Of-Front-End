import Mock from 'mockjs'

"name|min-max"
//String  类型的数据
const data = Mock.mock({
    "string|1-10": "★"
})
// console.log(data);   //生成随机数量的★  最少1个，最多10个
const data1 = Mock.mock({
    "string|4": "★"
})
// console.log(data1);  //★★★★

const text = Mock.mock({
    //默认生成一个随机字
    string: '@cword()'
})
// console.log(text);

const title = Mock.mock({
    title: '@ctitle()'
})
// console.log(title);

const sentence = Mock.mock({
    string: '@csentence()'
})
// console.log(sentence);


const content = Mock.mock({
    content: '@cparagraph(3)'
})
// console.log(content);

const num = Mock.mock({
    number: 10
})
// console.log(num);

const num1 = Mock.mock({
    'number|1-100': 10
})
// console.log(num1);


const nums = Mock.mock({
    'number|1-10.1-3': 1
})
// console.log(nums);

const email = Mock.mock('@email()')
// console.log(email);


const id = Mock.mock({
    name: '@cname()',
    idCard: '@id()',
    address: '@city(false)'
})
// console.log(id);

const img = Mock.mock({
    img_url: "@image('200x100','#FF6600', 'png', 'mock')"
})
// console.log(img);

const date = Mock.mock({
    //yyyy-MM-dd hh:mm:ss
    date: '@date(yyyy-MM-dd hh:mm:ss)'
})
// console.log(date);


//生成数组一个数组
// const list = Mock.mock({
//     list: [
//         {
//             name: '@cname()',
//             address: '@city(true)',
//             id: '@increment(1)'
//         }
//     ]
// })

const list = Mock.mock({
    'list|3-10': [
        {
            name: '@cname()',
            address: '@city(true)',
            id: '@increment(2)'
        }
    ]
})

// console.log(list);

//定义拦截get请求
Mock.mock('/api/news', 'get', {
    state: 200,
    msg: 'get获取数据成功'
})

//定义拦截post请求
Mock.mock('/api/post/news', 'post', () => {
    return {
        state: 200,
        msg: 'post获取数据成功'
    }
})


