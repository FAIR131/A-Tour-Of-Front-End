<template>
  <el-form ref="coach"
           :rules="rules"
           :model="coachLicense"
           label-position="left"
           class="demo-ruleForm">
    <el-form-item>
      <el-input :placeholder="'请输入'+item+'证'+(type=='list'?'挂牌价格':'合作价格')"
                v-model="coachLicense.listPrice">
        <template slot="prepend">{{item}}证{{type=='list'?'挂牌价格':'合作价格'}}</template>
      </el-input>
    </el-form-item>
    <el-form-item>
      <el-card>
        <div slot="header"
             class="clearfix">
          <span>价格组成(普通班)</span>
        </div>
        <el-form-item prop="coachImgs">
          <el-upload class="upload-demo"
                     drag
                     :action="this.$http.defaults.baseURL+'/file/uploadFile'"
                     multiple
                     :on-success="getGeneralList">
            <i class="el-icon-upload"></i>
            <div class="el-upload__text">将价格组成的照片拖到此处，或<em>点击上传</em></div>
            <div class="el-upload__tip"
                 slot="tip">只能上传jpg/png文件，且不超过500kb</div>
          </el-upload>
        </el-form-item>
      </el-card>
    </el-form-item>
    <el-form-item label="备注">
      <el-input type="textarea"
                :rows="2"
                placeholder="选填"
                v-model="coachLicense.remarks">
      </el-input>
    </el-form-item>
  </el-form>
</template>
<script>
export default {
  props: {
    item: { type: String, default: {} },
    type: { type: String, default: '' },
  },
  data: function () {
    return {
      coachLicense: {
        generalList: '',
        remarks: '',
      },
      rules: {
        listPrice: [{ required: true, message: '请输入价格', trigger: 'blur' }],
        generalList: [
          {
            required: true,
            message: '请上传价格组成的图片',
            trigger: 'blur',
          },
        ],
      },
    }
  },
  methods: {
    getGeneralList: function (res, file, fileList) {
      this.coachLicense.generalList = res.object.url
    },
  },
  beforeDestroy: function () {
    let license = {}
    if (this.type == 'list') {
      license.licenseType = this.item
      license.listPrice = this.coachLicense.listPrice
      license.generalList = this.coachLicense.generalList
      license.listRemarks = this.coachLicense.remarks
    } else if (this.type == 'cooperate') {
      license.licenseType = this.item
      license.cooperatePrice = this.coachLicense.listPrice
      license.generalCooperate = this.coachLicense.generalList
      license.cooperateRemarks = this.coachLicense.remarks
    }
    this.$store.dispatch('CoachModule/addLicense', license)
  },
}
</script>
<style>
</style>