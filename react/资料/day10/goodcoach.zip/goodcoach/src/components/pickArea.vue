<template>
    <div>
        <el-select v-model="prov" style="width:32%;">
            <el-option v-for="(option,index) in arr" :value="option.name" :key="index">
                {{ option.name }}
            </el-option>
        </el-select>
        <el-select v-model="city" style="width:32%;">
            <el-option v-for="(option,index) in cityArr" :value="option.name" :key="index">
                {{ option.name }}
            </el-option>
        </el-select>
        <el-select v-model="district" v-if="showArea" style="width:32%;">
            <el-option v-for="(option,index) in districtArr" :value="option.name" :key="index">
                {{ option.name }}
            </el-option>
        </el-select>
    </div>
</template>
<script>
    import area from '../utils/area.js'  //这里引入城市信息
    export default {
        name: 'Cselect',
        props:{
            showArea:{
                type:Boolean,
                default:true
            },
            imProv:{
                type:String,
                default:'省份',
            },
            imCity:{
                type:String,
                default:'城市',
            },
            imdistrict:{
                 type:String,
                default:'区域',
                }
        },
        data() {
            return {
                arr: area.arrAll,
                prov: this.imProv,
                city: this.imCity,
                district: this.imdistrict,
                cityArr: [],
                districtArr: [],
            }
        },
        methods: {
            updateCity: function() {
                for (var i in this.arr) {
                var obj = this.arr[i];
                if (obj.name) {
                    if (obj.name == this.prov) {
                    this.cityArr = obj.sub;
                    break;
                    }
                }
                }
                if(!this.cityArr[1]){
                    this.city = this.cityArr[0].name;
                    return;
                }
                this.city = this.cityArr[1].name;
            },
            updateDistrict: function() {
                for (var i in this.cityArr) {
                    var obj = this.cityArr[i];
                    if (obj.name == this.city) {
                        this.districtArr = obj.sub;
                        break;
                    }
                }
                if (this.districtArr && this.districtArr.length > 0 ) {
                    if(!this.districtArr[1]){
                        this.district = this.districtArr[0].name;
                        return;
                    }
                    this.district = this.districtArr[1].name;
                } else {
                    this.district = '';
                }
            }
        },
        beforeMount() {
            this.updateCity();
            this.updateDistrict();
        },
        watch: {
            prov: function() {
                this.updateCity();
                this.updateDistrict();
            },
            city: function() {                
                this.updateDistrict();
            },
            district:function(){
                this.$emit('getSite',this.prov,this.city,this.district);
            }
        }
    }
</script>
          
