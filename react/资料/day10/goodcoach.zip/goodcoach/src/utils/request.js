import axios from 'axios'
import {Message} from 'element-ui'
import store from '../store'

var instance = axios.create({
    timeout:5000
})

if (process.env.NODE_ENV === 'development') {
    // 开发环境
    instance.defaults.baseURL = 'http://47.92.101.231:1404';
    // instance.defaults.baseURL = 'https://coach.zjcjj.net/hjlconsole';
    // ping 192.168.11.238
} else {
    // 生产环境
    instance.defaults.baseURL = 'https://coach.zjcjj.net/hjlconsole';
}

// instance.defaults.headers.common['Authorization'] = AUTH_TOKEN;
// instance.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
instance.defaults.headers.post['Content-Type'] = 'application/json';



// 添加请求拦截器
instance.interceptors.request.use(function (config) {
    config.headers.token=store.state.LoginModule.token;    

    // if(config.method=="post"){
    //     config.data=qs.stringify(config.data);
    // }
    
    // 在发送请求之前做些什么    
    return config;
  }, function (error) {
    // 对请求错误做些什么
    return Promise.reject(error);
  });


// 添加响应拦截器
instance.interceptors.response.use(function (response) {
    // 响应成功了，数据错误
    // 对响应数据做点什么
    return response.status==200?Promise.resolve(response):Promise.reject(response);

  }, function (error) {
    // 响应失败
    // 对响应错误做点什么
    const {response}=error;    
    if(response){
        errORHandle(response.status,response.data)
    }else{
        Message.error("网络请求中断") 
    }    
    return Promise.reject(error);
  });

  function errORHandle(status,other){
    switch(status){
        case 400:
            Message.error("请求参数有问题，服务器无法识别。") 
            break;
        case 403:
            Message.error("服务器拒绝响应。权限不足。") 
            break;
        case 404:
            Message.error("URL无效或者URL有效但是没有资源。")
            break;
        case 500:
            Message.error("服务器内部错误，未捕获。")
            break;
        default:
            Message.error(other)    
            break;     
    }
}

export default instance