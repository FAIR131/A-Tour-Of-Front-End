import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../views/Login.vue'
import store from '../store'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect:"/login"
  },
  {
    path: '/login',
    component: Login
  },
  {
    path: '/home',
    component: resolve => (require(['../views/Home.vue'],resolve)),
    children:[
      {
        path:"/bizList",
        component: resolve => (require(['../views/business/bizList.vue'],resolve))
      },
      {
        path:"/bizVerify",
        component: resolve => (require(['../views/business/bizVerify.vue'],resolve))
      },
      {
        path:"/inputOrder",
        component: resolve => (require(['../views/order/inputOrder.vue'],resolve))
      },
      {
        path:"/inquiryOrder",
        component: resolve => (require(['../views/order/inquiryOrder.vue'],resolve))
      },
      {
        path:"/orderList",
        component: resolve => (require(['../views/order/orderList.vue'],resolve))
      },
      {
        path:"/userManage",
        component: resolve => (require(['../views/user/UserManage.vue'],resolve))
      },
      {
        path:"/roleManage",
        component: resolve => (require(['../views/user/RoleManage.vue'],resolve))
      },
      {
        path:"/inputCoach",
        component:resolve => (require(['../views/coach/inputCoach.vue'],resolve)),
        children:[
            {
                path:"/",
                component:resolve => (require(['../views/coach/inputCoach/Step1.vue'],resolve)),
            },
            {
                path:"/step1",
                component:resolve => (require(['../views/coach/inputCoach/Step1.vue'],resolve)),
            },
            {
                path:"/step2",
                component:resolve => (require(['../views/coach/inputCoach/Step2.vue'],resolve)),
            },
            {
                path:"/step3",
                component:resolve => (require(['../views/coach/inputCoach/Step3.vue'],resolve)),
            },
            {
                path:"/step4",
                component:resolve => (require(['../views/coach/inputCoach/Step4.vue'],resolve)),
            },
            {
                path:"/step5",
                component:resolve => (require(['../views/coach/inputCoach/Step5.vue'],resolve)),
            },
            {
                path:"/commit",
                component:resolve => (require(['../views/coach/inputCoach/Commit.vue'],resolve)),
            }
        ]
      },
      {
        path:"/coachExamine",
        component:resolve => (require(['../views/coach/coachExamine.vue'],resolve))
      },
      {
        path:"/coachList",
        component:resolve => (require(['../views/coach/coachList.vue'],resolve))
      },
      {
          path:"/coachSubmitted",
          component:resolve => (require(['../views/coach/coachSubmitted.vue'],resolve))
      }
    ]
  },
]

const router = new VueRouter({
  mode: 'history',
  // base: '/hjlconsole/',
  routes
})

router.beforeEach(function(to,from,next){
  if(to.path!=="/login"&&!store.state.LoginModule.token){
    next("/login");
  }  
  next();
})

export default router
