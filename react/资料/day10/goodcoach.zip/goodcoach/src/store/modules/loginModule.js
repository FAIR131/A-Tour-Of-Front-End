export default {
    namespaced:true,
    state: {
        currentUser:{},
        token:""
    },
    mutations: {
        setUser:function(state,user={}){
            state.currentUser=user;
        },
        setToken:function(state,value){
            state.token=value;
        },
        clearUser:function(state){
            state.currentUser={}
        },
        clearToken:function(state){
            state.token=""
        }
    },
    actions: {
        setUser(context,user){
			context.commit('setUser',user);
		},
        setToken(context,token){
			context.commit('setToken',token);
		},
        clearUser:function(context){
            context.commit('clearUser');
        },
        clearToken:function(context){
            context.commit('clearToken');
        }
    },
    getters:{
		getCurrentUser:state=>{
			return state.currentUser;
		}
	}
}