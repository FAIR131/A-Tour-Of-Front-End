export default {
    namespaced:true,
    state: {
        newCoach:{
            licenses:[]
        }
    },
    mutations: {
        setCoach:function(state,coach={}){
            for (const key in coach) {
				state.newCoach[key] = coach[key];
			}
        },
        clearCoach:function(state){
            state.newCoach={}
        },
        addLicense:function(state,license){
            let flag=true;
            state.newCoach.licenses.forEach(item => {
                if(item.licenseType==license.licenseType){
                    flag=false;
                    for (const key in license) {
                        item[key] = license[key];
                    }
                }
            });
            if(flag){
                state.newCoach.licenses.push(license);
            }
        }
    },
    actions: {
        setCoach:function(context,coach={}){
            context.commit('setCoach',coach);
        },
        clearCoach:function(context){
            context.commit('clearCoach');
        },
        addLicense:function(context,license){
            context.commit('addLicense',license);
        }
    },
    getters:{
		getNewCoach:state=>{
			return state.newCoach;
		}
	}
}