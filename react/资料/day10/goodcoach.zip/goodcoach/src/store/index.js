import Vue from 'vue'
import Vuex from 'vuex'
import LoginModule from './modules/loginModule'
import CoachModule from './modules/coachModule'


Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    currentUser:{}
  },
  mutations: {
    setUser:function(state,user={}){
      state.currentUser=user;
    }
  },
  actions: {
  },
  modules: {
    LoginModule,CoachModule
  }
})
