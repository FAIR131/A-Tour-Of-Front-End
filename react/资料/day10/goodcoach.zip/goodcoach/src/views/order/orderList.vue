<template>
  <div>
    <el-table :data="orders"
              stripe
              row-key="id">
      <el-table-column prop="orderNo"
                       label="订单编号"></el-table-column>
      <el-table-column prop="memberName"
                       label="买家会员名"></el-table-column>
      <el-table-column prop="memberAlipay"
                       label="买家支付宝账号"></el-table-column>
      <el-table-column prop="consigneeName"
                       label="收货人姓名"></el-table-column>
      <el-table-column prop="handset"
                       label="联系手机"></el-table-column>
      <el-table-column prop="receiveAddress"
                       label="收获地址"></el-table-column>
      <el-table-column prop="createDate"
                       label="下单时间"></el-table-column>
      <el-table-column prop="orderStatus"
                       label="订单状态"></el-table-column>
      <el-table-column prop
                       label="操作">
        <template v-slot="scope">
          <el-button size="mini"
                     type="primary"
                     @click="getDetail(scope.row)">详情</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog title="订单详情"
               :visible.sync="centerDialogVisible"
               width="40%"
               center>
      <el-form ref="form"
               label-position="left"
               label-width="18%">
        <el-form-item label="订单编号:">
          {{newObj.orderNo}}
        </el-form-item>
        <el-form-item label="买家会员名:">
          {{newObj.memberName}}
        </el-form-item>
        <el-form-item label="买家支付宝账号:">
          {{newObj.memberAlipay}}
        </el-form-item>
        <el-form-item label="收货人姓名:">
          {{newObj.consigneeName}}
        </el-form-item>
        <el-form-item label="联系手机:">
          {{newObj.handset}}
        </el-form-item>
        <el-form-item label="收获地址:">
          {{newObj.receiveAddress}}
        </el-form-item>
        <el-form-item label="订单状态:">
          {{newObj.orderStatus}}
        </el-form-item>
        <el-form-item label="宝贝标题:">
          {{newObj.goodsTitle}}
        </el-form-item>
        <el-form-item label="订单备注:">
          {{newObj.orderRemark}}
        </el-form-item>
        <el-form-item label="商家备忘:">
          {{newObj.storeRemark}}
        </el-form-item>
        <el-form-item label="下单时间:">
          {{newObj.createDate}}
        </el-form-item>
        <el-form-item label="支付时间:">
          {{newObj.payDate}}
        </el-form-item>
        <el-form-item label="发货时间:">
          {{newObj.deliveryDate}}
        </el-form-item>

        <el-form-item label="买家应付货款:">
          {{newObj.shouldPayAmount}}
        </el-form-item>
        <el-form-item label="买家应付邮费:">
          {{newObj.shouldPayPostage}}
        </el-form-item>
        <el-form-item label="买家支付积分:">
          {{newObj.memberPayIntegral}}
        </el-form-item>
        <el-form-item label="总金额:">
          {{newObj.totalAmount}}
        </el-form-item>
        <el-form-item label="返点积分:">
          {{newObj.rebateIntegral}}
        </el-form-item>
        <el-form-item label="买家实际支付金额:">
          {{newObj.actualPayAmount}}
        </el-form-item>
        <el-form-item label="买家实际支付金额:">
          {{newObj.actualPayIntegral}}
        </el-form-item>
      </el-form>
    </el-dialog>

    <el-pagination background
                   layout="prev, sizes,pager, next, jumper"
                   :total="total"
                   @current-change="handleCurrentChange"
                   @size-change="handleSizeChange"
                   :page-sizes="[5, 10, 15, 20]"
                   :page-size="10"></el-pagination>
  </div>
</template>
<script>
export default {
  inject: ['reload'],
  data: function () {
    return {
      fileList: [],
      orders: [],
      total: 0,
      centerDialogVisible: false,
      newObj: {},
      pageSize: 10,
      headers: {
        token: this.$store.state.LoginModule.token,
      },
    }
  },
  async created() {
    this.handleCurrentChange(1)
  },
  methods: {
    handleCurrentChange: async function (val) {
      const { data } = await this.$http.get(
        `/order/getOrders?pageNum=${val}&pageSize=${this.pageSize}`
      )
      if (data.code == 1) {
        this.orders = data.object.list
        this.total = data.object.total
      } else {
        this.$message({
          message: data.message,
          type: 'error',
        })
      }
    },
    getDetail: async function (obj) {
      this.newObj = obj
      // const {data} = await this.$http.get(`/order/getCarsByOrderId?merchantOrderId=${obj.id}`);
      // this.newObj.cars=data.object;
      this.centerDialogVisible = true
    },
    handleExceed(files, fileList) {
      this.$message.warning(
        `当前限制选择 1 个文件，本次选择了 ${files.length} 个文件，共选择了 ${
          files.length + fileList.length
        } 个文件`
      )
    },
    updateData: function () {
      this.handleCurrentChange(1)
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.handleCurrentChange(1)
    },
  },
}
</script>
<style scoped>
.el-form-item.show-pic .el-image {
  margin: 0 10px;
}
</style>