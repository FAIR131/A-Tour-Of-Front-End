<template>
  <div>
    <el-card class="box-card">
      <div slot="header"
           class="clearfix">
        <span>筛选教练</span>
        <el-divider></el-divider>
        <el-form ref="form"
                 :inline="true"
                 :model="form"
                 class="demo-form-inline"
                 label-width="120px">
          <el-form-item label="教练名称">
            <el-input v-model="form.name"></el-input>
          </el-form-item>
          <el-form-item label="教练籍贯">
            <pickArea :showArea="false"
                      @getSite="setNativePlace" />
          </el-form-item>
          <el-form-item label="教练性别">
            <el-radio-group v-model="form.gender">
              <el-radio label="1">男</el-radio>
              <el-radio label="2">女</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-divider></el-divider>
          <el-form-item label="居住地址">
            <pickArea @getSite="setArea" />
            <el-input v-model="form.address"></el-input>
          </el-form-item>

          <el-divider></el-divider>
          <el-form-item>
            <el-button type="primary"
                       @click="onSubmit">查询</el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-card>

    <el-divider></el-divider>

    <el-table :data="coachs">
      <el-table-column prop="name"
                       label="教练名称"></el-table-column>
      <el-table-column prop="gender"
                       label="教练性别">
        <template v-slot="scope">
          {{scope.row.gender==1?"男":"女"}}
        </template>
      </el-table-column>
      <el-table-column prop="phone"
                       label="教练电话"></el-table-column>
      <el-table-column prop="wechat"
                       label="教练微信"></el-table-column>
      <el-table-column prop="schoolName"
                       label="驾校名称"></el-table-column>
      <el-table-column prop
                       label="操作">
        <template v-slot="scope">
          <el-button size="mini"
                     type="primary"
                     @click="getDetail(scope.row)">详情</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog title="教练详情"
               :visible.sync="coachDetailVisible"
               width="80%"
               center>
      <el-descriptions :border="true">
        <el-descriptions-item label="教练名称">
          <el-tag size="small">{{newObj.name}}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="教练性别">{{newObj.gender==1?"男":"女"}}</el-descriptions-item>
        <el-descriptions-item label="教练电话">{{newObj.phone}}</el-descriptions-item>
        <el-descriptions-item label="教练微信">{{newObj.wechat}}</el-descriptions-item>
        <el-descriptions-item label="教练籍贯">{{newObj.nativePlace}}</el-descriptions-item>
        <el-descriptions-item label="教练生日">{{newObj.birthday}}</el-descriptions-item>
        <el-descriptions-item label="居住地址">{{newObj.province}}{{newObj.city}}{{newObj.area}}{{newObj.address}}</el-descriptions-item>
        <el-descriptions-item label="驾校名称">{{newObj.schoolName}}</el-descriptions-item>
        <el-descriptions-item label="执教年限">{{newObj.teachYears}}年</el-descriptions-item>
        <el-descriptions-item label="车辆品牌">{{newObj.carBrand}}</el-descriptions-item>
        <el-descriptions-item label="变速器类型">{{newObj.transType==1?"手动":"自动"}}档</el-descriptions-item>
        <el-descriptions-item label="场地地址">
          <div v-for="(address,index) in newObj.fieldAddress"
               :key="index">{{index+1}}、{{address}}</div>
        </el-descriptions-item>
        <el-descriptions-item label="接送范围"
                              span="2">{{newObj.pickupRange}}</el-descriptions-item>
        <el-descriptions-item label="教练照片">
          <el-image v-for="(src,index) in newObj.coachImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.coachImgs"></el-image>
        </el-descriptions-item>
        <el-descriptions-item label="教练证照片">
          <el-image v-for="(src,index) in newObj.coachCardImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.coachCardImgs"></el-image>
        </el-descriptions-item>
        <el-descriptions-item label="短视频介绍">
          <video v-for="(src,index) in newObj.shortVideo"
                 :key="index"
                 style="width:100px;"
                 :src="src"
                 controls>

          </video>
        </el-descriptions-item>
        <el-descriptions-item label="特殊记忆点照片">
          <el-image v-for="(src,index) in newObj.specialMemoImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.specialMemoImgs"></el-image>
        </el-descriptions-item>
      </el-descriptions>
    </el-dialog>

    <el-pagination background
                   layout="prev, sizes,pager, next, jumper"
                   :total="total"
                   @current-change="handleCurrentChange"
                   @size-change="handleSizeChange"
                   :page-sizes="[5, 10, 15, 20]"
                   :page-size="pageSize"></el-pagination>
  </div>
</template>
<script>
import pickArea from '@/components/pickArea.vue'
export default {
  components: {
    pickArea,
  },
  data() {
    return {
      form: {
        name: '',
        gender: '',
        nativePlace: '',
        province: '',
        city: '',
        area: '',
        address: '',
        pageNum: 1,
        pageSize: this.pageSize,
        isValid: 1,
      },
      coachs: [],
      newObj: {},
      pageSize: 5,
      coachDetailVisible: false,
      total: 0,
    }
  },
  async created() {
    this.handleCurrentChange(1)
  },
  methods: {
    handleCurrentChange: async function (val) {
      this.form.pageNum = val
      const { data } = await this.$http.post(`/coach/getCoachs`, this.form)

      if (data.code == 1) {
        this.coachs = data.object.list
        this.coachs.forEach((coach) => {
          coach.fieldAddress = JSON.parse(coach.fieldAddress)
          coach.coachImgs = JSON.parse(coach.coachImgs)
          coach.coachCardImgs = JSON.parse(coach.coachCardImgs)
          coach.shortVideo = JSON.parse(coach.shortVideo)
          coach.specialMemoImgs = JSON.parse(coach.specialMemoImgs)
        })
        this.total = data.object.total
      } else {
        this.$message({
          message: data.message,
          type: 'error',
        })
      }
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.handleCurrentChange(1)
    },
    onSubmit() {
      this.handleCurrentChange(1)
    },
    setArea: function (province, city, area) {
      this.form.province = province
      this.form.city = city
      this.form.area = area
    },
    setNativePlace: function (province, city, area) {
      this.form.nativePlace = province + city
    },
    getDetail: async function (obj) {
      this.newObj = obj
      this.coachDetailVisible = true
    },
  },
}
</script>
<style scoped>
</style>