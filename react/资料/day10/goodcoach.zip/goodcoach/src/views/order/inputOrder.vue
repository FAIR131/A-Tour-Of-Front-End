<template>
  <div>
    <el-header>
      <el-upload class="upload-demo"
                 :action="this.$http.defaults.baseURL+'/file/uploadOrder'"
                 :headers="headers"
                 :on-exceed="handleExceed"
                 :on-success="updateData">
        <el-button size="small"
                   type="success">上传淘宝订单</el-button>
        <div slot="tip"
             class="el-upload__tip">只能上传Excel文件</div>
      </el-upload>
    </el-header>

    <el-table :data="orders"
              stripe
              row-key="id">
      <el-table-column prop="orderNo"
                       label="订单编号"></el-table-column>
      <el-table-column prop="memberName"
                       label="买家会员名"></el-table-column>
      <el-table-column prop="memberAlipay"
                       label="买家支付宝账号"></el-table-column>
      <el-table-column prop="consigneeName"
                       label="收货人姓名"></el-table-column>
      <el-table-column prop="handset"
                       label="联系手机"></el-table-column>
      <el-table-column prop="receiveAddress"
                       label="收获地址">
        <template v-slot="scope">
          {{scope.row.province}}{{scope.row.city}}{{scope.row.area}}{{scope.row.receiveAddress}}
        </template>
      </el-table-column>
      <el-table-column prop="createDate"
                       label="下单时间"></el-table-column>
      <el-table-column prop="orderStatus"
                       label="订单状态"></el-table-column>
      <el-table-column prop
                       label="操作">
        <template v-slot="scope">
          <el-button size="mini"
                     type="primary"
                     @click="getDetail(scope.row)">详情</el-button>
          <el-button size="mini"
                     type="danger"
                     @click="arrangeCoach(scope.row)">安排教练</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog title="订单详情"
               :visible.sync="orderDetailVisible"
               width="80%"
               center>
      <el-descriptions :border="true">
        <el-descriptions-item label="订单编号">{{newObj.orderNo}}</el-descriptions-item>
        <el-descriptions-item label="买家会员名">{{newObj.memberName}}</el-descriptions-item>
        <el-descriptions-item label="买家支付宝账号">{{newObj.memberAlipay}}</el-descriptions-item>
        <el-descriptions-item label="收货人姓名">
          <el-tag size="small">{{newObj.consigneeName}}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="联系手机">{{newObj.handset}}</el-descriptions-item>
        <el-descriptions-item label="收获地址">{{newObj.receiveAddress}}</el-descriptions-item>
        <el-descriptions-item label="订单状态">{{newObj.orderStatus}}</el-descriptions-item>
        <el-descriptions-item label="宝贝标题">{{newObj.goodsTitle}}</el-descriptions-item>
        <el-descriptions-item label="订单备注">{{newObj.orderRemark}}</el-descriptions-item>
        <el-descriptions-item label="商家备忘">{{newObj.storeRemark}}</el-descriptions-item>
        <el-descriptions-item label="下单时间">{{newObj.createDate}}</el-descriptions-item>
        <el-descriptions-item label="支付时间">{{newObj.payDate}}</el-descriptions-item>
        <el-descriptions-item label="发货时间">{{newObj.deliveryDate}}</el-descriptions-item>
        <el-descriptions-item label="买家应付货款">{{newObj.shouldPayAmount}}</el-descriptions-item>
        <el-descriptions-item label="买家应付邮费">{{newObj.shouldPayPostage}}</el-descriptions-item>
        <el-descriptions-item label="买家支付积分">{{newObj.memberPayIntegral}}</el-descriptions-item>
        <el-descriptions-item label="总金额">{{newObj.totalAmount}}</el-descriptions-item>
        <el-descriptions-item label="返点积分">{{newObj.rebateIntegral}}</el-descriptions-item>
        <el-descriptions-item label="买家实际支付金额">{{newObj.actualPayAmount}}</el-descriptions-item>
        <el-descriptions-item label="买家实际支付积分">{{newObj.actualPayIntegral}}</el-descriptions-item>
      </el-descriptions>
    </el-dialog>

    <el-dialog title="安排教练"
               :visible.sync="arrangeCoachVisible"
               center>
      <el-radio-group v-model="pickedCoach"
                      style="width:100%;">
        <el-table :data="coachs"
                  empty-text="学员所在地区暂无合作的教练">
          <el-table-column label="选择"
                           prop="id">
            <template v-slot="scope">
              <el-radio :label="scope.row">{{scope.row.name}}</el-radio>
            </template>
          </el-table-column>
          <el-table-column prop="gender"
                           label="教练性别">
            <template v-slot="scope">
              {{scope.row.gender==1?"男":"女"}}
            </template>
          </el-table-column>
          <el-table-column prop="phone"
                           label="教练电话"></el-table-column>
          <el-table-column prop="wechat"
                           label="教练微信"></el-table-column>
          <el-table-column prop="schoolName"
                           label="驾校名称"></el-table-column>
        </el-table>
      </el-radio-group>
      <span slot="footer"
            class="dialog-footer">
        <el-button size="mini"
                   type="primary"
                   @click="arrangeCoachVisible=false">取消</el-button>
        <el-button size="mini"
                   type="danger"
                   @click="submitArrage()">安排</el-button>
      </span>
    </el-dialog>

    <el-pagination background
                   layout="prev, sizes,pager, next, jumper"
                   :total="total"
                   @current-change="handleCurrentChange"
                   @size-change="handleSizeChange"
                   :page-sizes="[5, 10, 15, 20]"
                   :page-size="pageSize"></el-pagination>
  </div>
</template>
<script>
export default {
  inject: ['reload'],
  data: function () {
    return {
      pickedCoach: null,
      pickedStudent: null,
      orders: [],
      coachs: [],
      total: 0,
      orderDetailVisible: false,
      arrangeCoachVisible: false,
      newObj: {},
      pageSize: 5,
      headers: {
        token: this.$store.state.LoginModule.token,
      },
    }
  },
  async created() {
    this.handleCurrentChange(1)
  },
  methods: {
    handleCurrentChange: async function (val) {
      const { data } = await this.$http.get(
        `/order/getTaobaoOrders?pageNum=${val}&pageSize=${this.pageSize}`
      )
      if (data.code == 1) {
        this.orders = data.object.list
        this.total = data.object.total
      } else {
        this.$message({
          message: data.message,
          type: 'error',
        })
      }
    },
    getDetail: async function (obj) {
      this.newObj = obj
      this.orderDetailVisible = true
    },
    handleExceed(files, fileList) {
      this.$message.warning(
        `当前限制选择 1 个文件，本次选择了 ${files.length} 个文件，共选择了 ${
          files.length + fileList.length
        } 个文件`
      )
    },
    updateData: function () {
      this.handleCurrentChange(1)
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.handleCurrentChange(1)
    },
    arrangeCoach: async function (obj) {
      this.pickedCoach = null
      this.pickedStudent = obj
      obj.isValid = 1
      const { data } = await this.$http.post(`/coach/getCoachs`, obj)
      if (data.code == 1) {
        this.coachs = data.object.list
      } else {
        this.$message({
          message: data.message,
          type: 'error',
        })
      }
      this.arrangeCoachVisible = true
    },
    submitArrage: async function () {
      if (this.pickedCoach == null) {
        this.$message({
          message: '没有选择教练,无法安排',
          type: 'error',
        })
        return
      }

      console.log(this.pickedCoach, this.pickedStudent)
      // 此处数据订单提交后台生成订单，并通知到商务
    },
  },
}
</script>
<style scoped>
.el-form-item.show-pic .el-image {
  margin: 0 10px;
}
</style>