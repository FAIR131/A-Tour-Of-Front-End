<template>
  <div>
    <el-table :data="coachs">
      <el-table-column prop="name"
                       label="教练名称"></el-table-column>
      <el-table-column prop="phone"
                       label="教练电话"></el-table-column>
      <el-table-column prop="wechat"
                       label="教练微信"></el-table-column>
      <el-table-column prop="address"
                       label="居住地址"></el-table-column>
      <el-table-column prop="schoolName"
                       label="驾校名称"></el-table-column>
      <el-table-column label="状态">
        <template v-slot="scope">
          <el-tag size="small"
                  v-if="scope.row.isValid==0">未提审</el-tag>
          <el-tag size="small"
                  v-else-if="scope.row.isValid==1">经理审核中</el-tag>
          <el-tag size="small"
                  v-else-if="scope.row.isValid==2">副总审核中</el-tag>
          <el-tag size="small"
                  v-else-if="scope.row.isValid==3">总经理审核中</el-tag>
          <el-tag size="small"
                  v-else>审核通过</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template v-slot="scope">
    
          <el-button size="mini"
                     type="details"
                     v-if="scope.row.isValid>1"
                     @click="getDetail(scope.row)">详情</el-button>

          <el-button size="mini"
                     type="primary"
                     v-if="scope.row.isValid<2"
                     @click="updateCoach(scope.row)">修改</el-button>
                     
          <el-button size="mini"
                     type="danger"
                     v-if="scope.row.isValid<=3 && scope.row.isValid >=1"
                     @click="revokeExamine(scope.row)">撤审</el-button>
          <el-button size="mini"
                     type="success"
                     v-if="scope.row.isValid==0"
                     @click="submitExamine(scope.row)">提审</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog title="教练信息修改"
               :visible.sync="centerDialogVisible"
               width="80%"
               center>
      <el-descriptions :border="true">
        <el-descriptions-item label="教练名称">
          <el-input v-model="newObj.name"></el-input>
        </el-descriptions-item>
        
        <el-descriptions-item label="教练性别"
                    prop="gender">
          <el-radio v-model="radio" label="1">男</el-radio>
          <el-radio v-model="radio" label="2">女</el-radio>
        </el-descriptions-item >

        <el-descriptions-item label="教练电话">
          <el-input v-model="newObj.phone"></el-input>
        </el-descriptions-item>
        <el-descriptions-item label="教练微信">
          <el-input v-model="newObj.wechat"></el-input>
        </el-descriptions-item>

        <el-descriptions-item label="教练籍贯" 
                    v-model="newObj.nativePlace"
                    prop="nativePlace">

        <pickArea :showArea="false" :imCity="newObj.city" :imProv="newObj.province" :imdistrict="newObj.area"
                  @getSite="setNativePlace"
                  />

          </el-descriptions-item>
        <el-descriptions-item label="教练生日">
          <el-input v-model="newObj.birthday"></el-input>
          </el-descriptions-item>
          
        <el-descriptions-item label="居住地址" prop="address">
          <pickArea :showArea="true" :imCity="newObj.city" :imProv="newObj.province" :imdistrict="newObj.area" @getSite="setArea" v-model="newObj.address"/> 
          <el-input v-model="newObj.address"></el-input>
          </el-descriptions-item>

        <el-descriptions-item label="驾校名称">
          <el-input v-model="newObj.schoolName"></el-input>
          </el-descriptions-item>
        <el-descriptions-item label="执教年限">
          <el-input v-model="newObj.teachYears"></el-input>年
          </el-descriptions-item>

         <!-- <el-descriptions-item label="培训证件">
            <el-checkbox-group v-model="licenseType" > 
              <el-checkbox label="C1">C1证</el-checkbox>
              <el-checkbox label="C2">C2证</el-checkbox>
              <el-checkbox label="D">D证</el-checkbox>
              <el-checkbox label="E">E证</el-checkbox>
           </el-checkbox-group>
        </el-descriptions-item> -->
           <el-descriptions-item label="培训证件">
          <div v-for="(license,index) in newObj.licenseType"
               :key="index">
            <el-tag size="small">{{license}}证</el-tag>
          </div>
        </el-descriptions-item>
        
        <el-descriptions-item label="车辆品牌">
           <el-input v-model="newObj.carBrand"></el-input>
          </el-descriptions-item>
        <el-descriptions-item label="变速器类型">
            <el-radio-group v-model="transType">
            <el-radio label="1">手动档</el-radio>
            <el-radio label="2">自动档</el-radio>
          </el-radio-group>
        </el-descriptions-item>

        <el-descriptions-item label="场地地址"
                    prop="fieldAddress">
        <div v-for="(val,index) in newObj.fieldAddress"
             :key="index">
          <el-input v-model="newObj.fieldAddress[index]"
                    style="width:80%;vertical-align:top;"></el-input><i class="el-icon-remove-outline ctrl-btn"
             v-if="index != 0"
             @click="delOne(index)"></i><i class="el-icon-circle-plus-outline ctrl-btn"
             v-if="index == 0"
             @click="addOne"></i>
        </div>
        </el-descriptions-item> 

        <el-descriptions-item v-for="(item,index) in newObj.licenses"
                              :key="index"
                              :label="item.licenseType+'价格组成'">
          挂牌价组成：{{item.listRemarks}}
          <el-image v-if="item.generalList"
                    :src="item.generalList"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="[item.generalList]"></el-image>
          <el-divider></el-divider>
          合作价组成：{{item.cooperateRemarks}}
          <el-image v-if="item.generalCooperate"
                    :src="item.generalCooperate"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="[item.generalCooperate]"></el-image>
          <el-divider></el-divider>
          <el-tooltip v-if="currentUser.roleType!='guest'"
                      class="item"
                      effect="dark"
                      :content="item.licenseType+'挂牌价 : ￥'+item.listPrice+'，'+item.licenseType+'合作价 : ￥'+item.cooperatePrice"
                      placement="top-start">
            <i class="el-icon-s-opportunity"></i>
          </el-tooltip>
        </el-descriptions-item>

        <el-descriptions-item label="接送范围">
           <el-input v-model="newObj.pickupRange"></el-input>
          </el-descriptions-item>
        <el-descriptions-item label="教练照片">
          <el-image v-for="(src,index) in newObj.coachImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.coachImgs"></el-image>

          <el-upload class="avatar-uploader"
                     :action="this.$http.defaults.baseURL+'/file/uploadFile'"
                     :show-file-list="false"
                     :on-success="updateCoachImgs">
            <img v-if="imageUrl"
                 :src="imageUrl"
                 class="avatar">
            <i v-else
               class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-descriptions-item>
        <el-descriptions-item label="教练证照片">
          <el-image v-for="(src,index) in newObj.coachCardImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.coachCardImgs"></el-image>
          <el-upload class="avatar-uploader"
                     :action="this.$http.defaults.baseURL+'/file/uploadFile'"
                     :show-file-list="false"
                     :on-success="updateCoachCardImgs">
            <img v-if="imageUrl"
                 :src="imageUrl"
                 class="avatar">
            <i v-else
               class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-descriptions-item>
        <el-descriptions-item label="短视频介绍">
          <video v-for="(src,index) in newObj.shortVideo"
                 :key="index"
                 style="width:100px;"
                 :src="src"
                 controls>
          </video>
          <el-upload class="avatar-uploader"
                     :action="this.$http.defaults.baseURL+'/file/uploadFile'"
                     :show-file-list="false"
                     :on-success="updateShortVideoImgs">
            <img v-if="imageUrl"
                 :src="imageUrl"
                 class="avatar">
            <i v-else
               class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-descriptions-item>
        <el-descriptions-item label="特殊记忆点照片">
          <el-image v-for="(src,index) in newObj.specialMemoImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.specialMemoImgs"></el-image>
          <el-upload class="avatar-uploader"
                     :action="this.$http.defaults.baseURL+'/file/uploadFile'"
                     :show-file-list="false"
                     :on-success="updateSpecialMemoImgs">
            <img v-if="imageUrl"
                 :src="imageUrl"
                 class="avatar">
            <i v-else
               class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-descriptions-item>
        <el-descriptions-item label="教练合同">
          <el-image v-for="(src,index) in newObj.contractImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.contractImgs"></el-image>
          <el-upload class="avatar-uploader"
                     :action="this.$http.defaults.baseURL+'/file/uploadFile'"
                     :show-file-list="false"
                     :on-success="updateContractImgs">
            <img v-if="imageUrl"
                 :src="imageUrl"
                 class="avatar">
            <i v-else
               class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-descriptions-item>
      </el-descriptions>

      <span slot="footer"
            class="dialog-footer">
        <el-button type="primary"
                   @click="submitCoach(newObj)">更 新</el-button>
      </span>
    </el-dialog>
    <!-- --------------------------- -->
    <el-dialog title="教练信息详情"
               :visible.sync="coachDetailVisible"
               width="80%"
               center>
      <el-descriptions :border="true">
        <el-descriptions-item label="教练名称">
          <el-tag size="small">{{newObj.name}}</el-tag>

        </el-descriptions-item>
        <el-descriptions-item label="教练性别">{{newObj.gender==1?"男":"女"}}</el-descriptions-item>
        <el-descriptions-item label="教练电话">{{newObj.phone}}</el-descriptions-item>
        <el-descriptions-item label="教练微信">{{newObj.wechat}}</el-descriptions-item>
        <el-descriptions-item label="教练籍贯">{{newObj.nativePlace}}</el-descriptions-item>
        <el-descriptions-item label="教练生日">{{newObj.birthday}}</el-descriptions-item>
        <el-descriptions-item label="居住地址">{{newObj.province}}{{newObj.city}}{{newObj.area}}{{newObj.address}}</el-descriptions-item>
        <el-descriptions-item label="驾校名称">{{newObj.schoolName}}</el-descriptions-item>
        <el-descriptions-item label="执教年限">{{newObj.teachYears}}年</el-descriptions-item>
        <el-descriptions-item label="培训证件">
          <div v-for="(license,index) in newObj.licenseType"
               :key="index">
            <el-tag size="small">{{license}}证</el-tag>
          </div>
        </el-descriptions-item>
        <el-descriptions-item label="车辆品牌">{{newObj.carBrand}}</el-descriptions-item>
        <el-descriptions-item label="变速器类型">{{newObj.transType==1?"手动":"自动"}}档</el-descriptions-item>
        <el-descriptions-item label="场地地址">
          <div v-for="(address,index) in newObj.fieldAddress"
               :key="index">{{index+1}}、{{address}}</div>
        </el-descriptions-item>

        <el-descriptions-item v-for="(item,index) in newObj.licenses"
                              :key="index"
                              :label="item.licenseType+'价格组成'">
          挂牌价组成：{{item.listRemarks}}
          <el-image v-if="item.generalList"
                    :src="item.generalList"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="[item.generalList]"></el-image>
          <el-divider></el-divider>
          合作价组成：{{item.cooperateRemarks}}
          <el-image v-if="item.generalCooperate"
                    :src="item.generalCooperate"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="[item.generalCooperate]"></el-image>
          <el-divider></el-divider>
          <el-tooltip v-if="currentUser.roleType!='guest'"
                      class="item"
                      effect="dark"
                      :content="item.licenseType+'挂牌价 : ￥'+item.listPrice+'，'+item.licenseType+'合作价 : ￥'+item.cooperatePrice"
                      placement="top-start">
            <i class="el-icon-s-opportunity"></i>
          </el-tooltip>
        </el-descriptions-item>

        <el-descriptions-item label="接送范围">{{newObj.pickupRange}}</el-descriptions-item>
        <el-descriptions-item label="教练照片">
          <el-image v-for="(src,index) in newObj.coachImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.coachImgs"></el-image>
        </el-descriptions-item>
        <el-descriptions-item label="教练证照片">
          <el-image v-for="(src,index) in newObj.coachCardImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.coachCardImgs"></el-image>
        
        </el-descriptions-item>
        <el-descriptions-item label="短视频介绍">
          <video v-for="(src,index) in newObj.shortVideo"
                 :key="index"
                 style="width:100px;"
                 :src="src"
                 controls>

          </video>
        
        </el-descriptions-item>
        <el-descriptions-item label="特殊记忆点照片">
          <el-image v-for="(src,index) in newObj.specialMemoImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.specialMemoImgs"></el-image>
        
        </el-descriptions-item>
        <el-descriptions-item label="教练合同">
          <el-image v-for="(src,index) in newObj.contractImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.contractImgs"></el-image>
         
        </el-descriptions-item>
      </el-descriptions>

    </el-dialog>

    <el-pagination background
                   layout="prev, sizes,pager, next, jumper"
                   :total="total"
                   @current-change="handleCurrentChange"
                   @size-change="handleSizeChange"
                   :page-sizes="[5, 10, 15, 20]"
                   :page-size="pageSize"></el-pagination>
  </div>
</template>
<script>
import pickArea from '@/components/pickArea.vue'
export default {
   components: {
    pickArea,
  },
  inject: ['reload'],
  data: function () {
    let currentUser = this.$store.getters['LoginModule/getCurrentUser']
    return {
      currentUser,
      coachs: [],
      centerDialogVisible: false,
      coachDetailVisible:false,
      newObj: {},
      pageSize: 5,
      total: 0,
      imageUrl: '',
      gender: '',
      licenseType: '',
      index:'',
      address:'',
      checkList: '',
      Siteaddress:'',
      checkList: [''],
      fieldAddress: '',
      radio: '',
      transType:'',
      nativePlace:''

    }
  },
  async created() {
    this.handleCurrentChange(1)
  },
  methods: {
    handleCurrentChange: async function (val) {
      const { data } = await this.$http.post(`/coach/getCoachs`, {
        pageNum: val,
        pageSize: this.pageSize,
        declareId: this.currentUser.id,
      })

      if (data.code == 1) {
        this.coachs = data.object.list
        this.coachs.forEach((coach) => {
          coach.fieldAddress = JSON.parse(coach.fieldAddress)
          coach.coachImgs = JSON.parse(coach.coachImgs)
          coach.coachCardImgs = JSON.parse(coach.coachCardImgs)
          coach.shortVideo = JSON.parse(coach.shortVideo)
          coach.specialMemoImgs = JSON.parse(coach.specialMemoImgs)
          coach.contractImgs = JSON.parse(coach.contractImgs)
        })
        this.total = data.object.total
      } else {
        this.$message({
          message: data.message,
          type: 'error',
        })
      }
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.handleCurrentChange(1)
    },
 
    getDetail: async function (obj) {
      this.newObj = obj

      if (typeof obj.licenseType === 'string') {
        this.newObj.licenseType = JSON.parse(obj.licenseType)
      }
      const { data } = await this.$http.get(
        `/coach/getCoachLicenses?coachId=${this.newObj.id}`
      )
      if (data.code == 1) {
        this.newObj.licenses = data.object
      } else {
        this.$message({
          message: data.message,
          type: 'error',
        })
      }
      this.coachDetailVisible = true
    },

    updateCoach: async function (obj) {
      this.newObj = obj
      if (typeof obj.licenseType === 'string') {
        this.newObj.licenseType = JSON.parse(obj.licenseType)
      }
      const { data } = await this.$http.get(
        `/coach/getCoachLicenses?coachId=${this.newObj.id}`
      )
      if (data.code == 1) {
        this.newObj.licenses = data.object
      } else {
        this.$message({
          message: data.message,
          type: 'error',
        })
      }
     
      this.transType = this.newObj.transType.toString()
      this.radio = this.newObj.gender.toString()
      this.licenseType = this.newObj.licenseType?this.newObj.licenseType:[]
      
      this.centerDialogVisible = true
    },
    setArea: function (province, city, area) {
      this.newObj.province = province
      this.newObj.city = city
      this.newObj.area = area
    },
    setNativePlace: function (province, city, area) {
      this.newObj.nativePlace = province + city
    },
    submitCoach: async function (obj) {
      obj.transType=this.transType
      obj.gender=this.radio
      obj.licenseType = this.licenseType
      
      const { data } = await this.$http.post(`/coach/updateCoach`, obj)
      if (data.code == 1) {
        this.$message.success('更新成功')
      } else {
        this.$message.error('更新失败')
      }
    },
    revokeExamine: async function (obj) {
      this.$confirm(`此操作将撤销对${obj.name}教练的审核, 是否继续?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(async () => {
          const { data } = await this.$http.get(
            `/coach/changeExamine?coachId=${obj.id}&isValid=0`
          )
          this.$message.success('撤销成功')
          this.reload()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消操作',
          })
        })
    },
    submitExamine: async function (obj) {
      this.$confirm(
        `此操作将提交${obj.name}教练的资料进行审核, 是否继续?`,
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
      )
        .then(async () => {
          const { data } = await this.$http.get(
            `/coach/changeExamine?coachId=${obj.id}&isValid=1`
          )
          this.$message.success('提审成功')
          this.reload()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消操作',
          })
        })
    },
    // 教练照片
    updateCoachImgs: function (res, file, fileList) {
      this.newObj.coachImgs.push(res.object.url)
    },
    // 教练证照片
    updateCoachCardImgs: function (res, file, fileList) {
      this.newObj.coachCardImgs.push(res.object.url)
    },
    // 短视频介绍
    updateShortVideoImgs: function (res, file, fileList) {
      this.newObj.shortVideo.push(res.object.url)
    },
    // 特殊记忆点照片
    updateSpecialMemoImgs: function (res, file, fileList) {
      this.newObj.specialMemoImgs.push(res.object.url)
    },
    // 教练合同
    updateContractImgs: function (res, file, fileList) {
      this.newObj.contractImgs.push(res.object.url)
    },
    // 籍贯
    updatenativePlace:function (res, file, fileList) {
      this.newObj.nativePlace.push(res.object.url)
    },
    // 添加现场地址
    addOne: function () {
      this.newObj.fieldAddress.push('')
    },
    delOne: function (index) {
      this.newObj.fieldAddress.splice(index, 1)
    },
    handleChange: function (value) {
      this.newObj.licenseType = value 
    },
  },
}
</script>
<style>
.el-form-item.show-pic .el-image {
  margin: 0 10px;
}
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 100%;
}
</style>