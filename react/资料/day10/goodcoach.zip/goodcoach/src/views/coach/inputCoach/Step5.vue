<template>
  <div>
    <el-steps :active="4"
              align-center>
      <el-step title="基本信息"></el-step>
      <el-step title="执教信息"></el-step>
      <el-step title="照片信息"></el-step>
      <el-step title="挂牌价格"></el-step>
      <el-step title="合作价格"></el-step>
    </el-steps>
    <el-divider></el-divider>
    <div v-for="(item,index) in newCoach.licenseType "
         :key="index">
      <pricePart :item="item"
                 type="cooperate" />
      <el-divider></el-divider>
    </div>
    <el-button type="primary"
               @click="prevStep()">上一步</el-button>
    <!-- <el-button type="primary"
               @click="submitCoach()">提交</el-button> -->
    <el-button type="primary"
               @click="nextStep()">提 交</el-button>
  </div>
</template>
<script>
import pricePart from '../../../components/pricePart.vue'
export default {
  components: {
    pricePart,
  },
  data: function () {
    return {
      checked: [],
      newCoach: null,
    }
  },
  async created() {
    this.newCoach = this.$store.getters['CoachModule/getNewCoach']
  },
  methods: {
    prevStep: function () {
      this.$router.go(-1)
    },
    nextStep() {
      this.$router.push('commit')
    },
    submitCoach: async function () {
      //   this.$refs['coach'].validate(async (valid) => {
      //     if (valid) {
      //   this.$store.commit('CoachModule/setCoach', this.coach)
      const { data } = await this.$http.post(
        `/coach/addCoach`,
        this.$store.getters['CoachModule/getNewCoach']
      )
      if (data.code == 1) {
        this.$message.success('创建成功，已进入审核流程')
      } else {
        this.$message.error('提交失败，请联系系统管理员')
      }
      //     } else {
      //       this.$message.error('提交失败，验证不通过')
      //       return false
      //     }
      //   })
    },
    handleChange(value) {
      this.coach.generalList = value
    },
  },
}
</script>
<style>
.el-form-item.show-pic .el-image {
  margin: 0 10px;
}
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 100%;
}
</style>