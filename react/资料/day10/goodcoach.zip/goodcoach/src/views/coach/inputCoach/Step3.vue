<template>
  <div>
    <el-steps :active="2"
              align-center>
      <el-step title="基本信息"></el-step>
      <el-step title="执教信息"></el-step>
      <el-step title="照片信息"></el-step>
      <el-step title="挂牌价格"></el-step>
      <el-step title="合作价格"></el-step>
    </el-steps>
    <el-divider></el-divider>
    <el-form ref="coach"
             :rules="rules"
             :model="coach"
             label-width="120px"
             label-position="left"
             class="demo-ruleForm">
      <el-form-item label="教练照片"
                    prop="coachImgs">
        <el-upload class="upload-demo"
                   drag
                   :action="this.$http.defaults.baseURL+'/file/uploadFile'"
                   multiple
                   :on-success="getCoachImgs">
          <i class="el-icon-upload"></i>
          <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
          <div class="el-upload__tip"
               slot="tip">只能上传jpg/png文件，且不超过500kb</div>
        </el-upload>
      </el-form-item>
      <el-form-item label="教练证照片"
                    prop="coachCardImgs">
        <el-upload class="upload-demo"
                   drag
                   :action="this.$http.defaults.baseURL+'/file/uploadFile'"
                   multiple
                   :on-success="getCoachCardImgs">
          <i class="el-icon-upload"></i>
          <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
          <div class="el-upload__tip"
               slot="tip">只能上传jpg/png文件，且不超过500kb</div>
        </el-upload>
      </el-form-item>
      <el-form-item label="短视频介绍"
                    prop="shortVideo">
        <el-upload class="upload-demo"
                   drag
                   :action="this.$http.defaults.baseURL+'/file/uploadFile'"
                   multiple
                   :on-success="getShortVideoImgs">
          <i class="el-icon-upload"></i>
          <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
          <div class="el-upload__tip"
               slot="tip">只能上传jpg/png文件，且不超过500kb</div>
        </el-upload>
      </el-form-item>
      <el-form-item label="特殊记忆点"
                    prop="specialMemoImgs">
        <el-upload class="upload-demo"
                   drag
                   :action="this.$http.defaults.baseURL+'/file/uploadFile'"
                   multiple
                   :on-success="getSpecialMemoImgs">
          <i class="el-icon-upload"></i>
          <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
          <div class="el-upload__tip"
               slot="tip">只能上传jpg/png文件，且不超过500kb</div>
        </el-upload>
      </el-form-item>
      <el-form-item label="教练合同"
                    prop="contractImgs">
        <el-upload class="upload-demo"
                   drag
                   :action="this.$http.defaults.baseURL+'/file/uploadFile'"
                   multiple
                   :on-success="getContractImgs">
          <i class="el-icon-upload"></i>
          <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
          <div class="el-upload__tip"
               slot="tip">只能上传jpg/png文件，且不超过500kb</div>
        </el-upload>
      </el-form-item>
      <el-form-item>
        <el-button type="primary"
                   @click="prevStep()">上一步</el-button>
        <el-button type="primary"
                   @click="nextStep()">下一步</el-button>
      </el-form-item>
    </el-form>

    <el-dialog :visible.sync="dialogVisible">
      <img width="100%"
           :src="dialogImageUrl"
           alt="">
    </el-dialog>
  </div>
</template>
<script>
export default {
  data: function () {
    return {
      coach: {
        coachImgs: [],
        coachCardImgs: [],
        shortVideo: [],
        specialMemoImgs: [],
        contractImgs: [],
      },
      rules: {
        // coachImgs: [
        //   {
        //     type: 'array',
        //     required: true,
        //     message: '请上传教练照片',
        //     trigger: 'blur',
        //   },
        // ],
        // coachCardImgs: [
        //   {
        //     type: 'array',
        //     required: true,
        //     message: '请上传教练证照片',
        //     trigger: 'change',
        //   },
        // ],
        // shortVideo: [
        //   {
        //     type: 'array',
        //     required: true,
        //     message: '请上传短视频介绍',
        //     trigger: 'change',
        //   },
        // ],
        // specialMemoImgs: [
        //   {
        //     type: 'array',
        //     required: true,
        //     message: '请上传特殊记忆点照片',
        //     trigger: 'blur',
        //   },
        // ],
        // contractImgs: [
        //   {
        //     type: 'array',
        //     required: true,
        //     message: '请上传教练合同',
        //     trigger: 'blur',
        //   },
        // ],
      },
      dialogImageUrl: '',
      dialogVisible: false,
      disabled: false,
    }
  },
  async created() {},
  methods: {
    prevStep: function () {
      this.$router.go(-1)
    },
    nextStep: function () {
      this.$refs['coach'].validate(async (valid) => {
        if (valid) {
          this.$store.dispatch('CoachModule/setCoach', this.coach)
          this.$router.push('step4')
        } else {
          this.$message.error('提交失败，验证不通过')
          return false
        }
      })
    },
    handleRemove: function (file) {
      // console.log(file);
    },
    handlePictureCardPreview: function (file) {
      this.dialogImageUrl = file.url
      this.dialogVisible = true
    },
    handleDownload: function (file) {
      // console.log(file);
    },
    getCoachImgs: function (res, file, fileList) {
      this.coach.coachImgs.push(res.object.url)
    },
    getCoachCardImgs: function (res, file, fileList) {
      this.coach.coachCardImgs.push(res.object.url)
    },
    getShortVideoImgs: function (res, file, fileList) {
      this.coach.shortVideo.push(res.object.url)
    },
    getSpecialMemoImgs: function (res, file, fileList) {
      this.coach.specialMemoImgs.push(res.object.url)
    },
    getContractImgs: function (res, file, fileList) {
      this.coach.contractImgs.push(res.object.url)
    },
  },
}
</script>
<style>
.el-form-item.show-pic .el-image {
  margin: 0 10px;
}
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 100%;
}
</style>