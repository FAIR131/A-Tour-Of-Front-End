<template>
  <div>
    <el-steps :active="0"
              align-center>
      <el-step title="基本信息"></el-step>
      <el-step title="执教信息"></el-step>
      <el-step title="照片信息"></el-step>
      <el-step title="挂牌价格"></el-step>
      <el-step title="合作价格"></el-step>
    </el-steps>
    <el-divider></el-divider>
    <el-form ref="coach"
             :rules="rules"
             :model="coach"
             label-width="120px"
             label-position="left"
             class="demo-ruleForm">
      <el-form-item label="培训证件"
                    prop="name">
        <el-checkbox-group @change="handleChange"
                           v-model="coach.licenseType">
          <el-checkbox label="C1">C1证</el-checkbox>
          <el-checkbox label="C2">C2证</el-checkbox>
          <el-checkbox label="D">D证</el-checkbox>
          <el-checkbox label="E">E证</el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <el-form-item label="教练名称"
                    prop="name">
        <el-input v-model="coach.name"></el-input>
      </el-form-item>
      <el-form-item label="教练性别"
                    prop="gender">
        <el-radio-group v-model="coach.gender">
          <el-radio label="1">男</el-radio>
          <el-radio label="2">女</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="教练生日"
                    prop="birthday">
        <el-date-picker type="date"
                        placeholder="选择日期"
                        v-model="coach.birthday"
                        style="width: 100%;"></el-date-picker>
      </el-form-item>
      <el-form-item label="教练籍贯"
                    prop="nativePlace">
        <pickArea :showArea="false"
                  @getSite="setNativePlace" />
      </el-form-item>
      <el-form-item label="教练手机"
                    prop="phone">
        <el-input v-model="coach.phone"></el-input>
      </el-form-item>
      <el-form-item label="教练微信"
                    prop="wechat">
        <el-input v-model="coach.wechat"></el-input>
      </el-form-item>
      <el-form-item label="居住地址"
                    prop="address">
        <pickArea @getSite="setArea" />
        <el-input v-model="coach.address"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary"
                   @click="nextStep()">下一步</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import pickArea from '@/components/pickArea.vue'
export default {
  components: {
    pickArea,
  },
  data: function () {
    return {
      coach: {
        name: '',
        gender: '',
        birthday: '',
        nativePlace: '',
        phone: '',
        wechat: '',
        province: '',
        city: '',
        area: '',
        address: '',
        licenseType: [],
      },
      rules: {
        licenseType: [
          {
            type: 'array',
            required: true,
            message: '请勾选培训证件',
            trigger: 'change',
          },
        ],
        name: [
          { required: true, message: '请输入教练名称', trigger: 'blur' },
          { min: 2, max: 4, message: '长度在 2 到 4 个字符', trigger: 'blur' },
        ],
        gender: [
          { required: true, message: '请选择教练性别', trigger: 'change' },
        ],
        birthday: [
          {
            type: 'date',
            required: true,
            message: '请选择教练生日',
            trigger: 'change',
          },
        ],
        nativePlace: [
          { required: true, message: '请输入教练籍贯', trigger: 'change' },
          {
            min: 3,
            max: 6,
            message: '长度在 3 到 6 个字符',
            trigger: 'change',
          },
        ],
        phone: [
          { required: true, message: '请输入教练电话', trigger: 'change' },
        ],
        wechat: [
          { required: true, message: '请输入教练微信', trigger: 'change' },
        ],
        address: [
          { required: true, message: '请填写教练住址', trigger: 'blur' },
        ],
      },
    }
  },
  async created() {},
  methods: {
    nextStep() {
      this.$refs['coach'].validate(async (valid) => {
        if (valid) {
          this.$store.dispatch('CoachModule/setCoach', this.coach)
          this.$router.push('step2')
        } else {
          this.$message.error('提交失败，验证不通过')
          return false
        }
      })
    },
    setArea: function (province, city, area) {
      this.coach.province = province
      this.coach.city = city
      this.coach.area = area
    },
    setNativePlace: function (province, city, area) {
      this.coach.nativePlace = province + city
    },
    handleChange: function (value) {
      this.coach.licenseType = value
    },
  },
}
</script>
<style>
.el-form-item.show-pic .el-image {
  margin: 0 10px;
}
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 100%;
}
</style>