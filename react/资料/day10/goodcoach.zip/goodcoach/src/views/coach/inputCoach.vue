<template>
  <div class="content">
    <router-view />
  </div>
</template>
<script>
export default {
  data: function() {
    return {}
      
  },
  created:()=>{
      
  },
  methods: {

  }
};
</script>
<style>
  .content{
    width:30%;
  }
  .el-form-item.show-pic .el-image{
    margin:0 10px;
  }
  .demo-table-expand {
    font-size: 0;
  }
  .demo-table-expand label {
    color: #99a9bf;
  }
  .demo-table-expand .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 100%;
  }
</style>