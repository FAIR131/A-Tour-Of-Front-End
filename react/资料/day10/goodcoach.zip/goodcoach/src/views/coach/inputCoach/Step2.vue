<template>
  <div>
    <el-steps :active="1"
              align-center>
      <el-step title="基本信息"></el-step>
      <el-step title="执教信息"></el-step>
      <el-step title="照片信息"></el-step>
      <el-step title="挂牌价格"></el-step>
      <el-step title="合作价格"></el-step>
    </el-steps>
    <el-divider></el-divider>
    <el-form ref="coach"
             :rules="rules"
             :model="coach"
             label-width="120px"
             label-position="left"
             class="demo-ruleForm">
      <el-form-item label="执教年限"
                    prop="teachYears">
        <el-input-number v-model="coach.teachYears"
                         :min="1"
                         :max="10"
                         label="执教年限"></el-input-number>
      </el-form-item>
      <el-form-item label="车辆品牌"
                    prop="carBrand">
        <el-input v-model="coach.carBrand"></el-input>
      </el-form-item>
      <el-form-item label="变速器类型"
                    prop="transType">
        <el-radio-group v-model="coach.transType">
          <el-radio label="1">手动</el-radio>
          <el-radio label="2">自动</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="所属驾校"
                    prop="schoolName">
        <el-input v-model="coach.schoolName"></el-input>
      </el-form-item>
      <el-form-item label="场地地址"
                    prop="fieldAddress">
        <div v-for="(val,index) in coach.fieldAddress"
             :key="index">
          <el-input v-model="coach.fieldAddress[index]"
                    style="width:80%;vertical-align:top;"></el-input><i class="el-icon-remove-outline ctrl-btn"
             v-if="index != 0"
             @click="delOne(index)"></i><i class="el-icon-circle-plus-outline ctrl-btn"
             v-if="index == 0"
             @click="addOne"></i>
        </div>
      </el-form-item>
      <el-form-item label="接送范围"
                    prop="pickupRange">
        <el-input v-model="coach.pickupRange"></el-input>
      </el-form-item>

      <el-form-item>
        <el-button type="primary"
                   @click="prevStep()">上一步</el-button>
        <el-button type="primary"
                   @click="nextStep()">下一步</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  data: function () {
    return {
      coach: {
        teachYears: 1,
        carBrand: '',
        transType: '',
        schoolName: '',
        fieldAddress: [''],
        pickupRange: '',
      },
      rules: {
        teachYears: [
          { required: true, message: '执教年限不能为空' },
          { type: 'number', message: '执教年限必须为数字值' },
        ],
        carBrand: [
          { required: true, message: '请选择车辆品牌', trigger: 'blur' },
        ],
        transType: [
          { required: true, message: '请选择变速器类型', trigger: 'change' },
        ],
        schoolName: [
          { required: true, message: '请输入驾校名称', trigger: 'blur' },
        ],
        fieldAddress: [
          {
            type: 'array',
            required: true,
            message: '请至少输入一个场地地址',
            trigger: 'blur',
          },
        ],
        pickupRange: [
          { required: true, message: '请输入接送范围', trigger: 'blur' },
        ],
      },
    }
  },
  async created() {},
  methods: {
    prevStep: function () {
      this.$router.go(-1)
    },
    nextStep() {
      this.$refs['coach'].validate(async (valid) => {
        if (valid) {
          this.$store.dispatch('CoachModule/setCoach', this.coach)
          this.$router.push('step3')
        } else {
          this.$message.error('提交失败，验证不通过')
          return false
        }
      })
    },
    addOne: function () {
      this.coach.fieldAddress.push('')
    },
    delOne: function (index) {
      this.coach.fieldAddress.splice(index, 1)
    },
  },
}
</script>
<style>
.el-form-item.show-pic .el-image {
  margin: 0 10px;
}
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 100%;
}
.ctrl-btn {
  font-size: 35px;
  color: #999;
}
</style>