<template>
  <div>
    <el-table :data="coachs">
      <el-table-column prop="name"
                       label="教练名称"></el-table-column>
      <el-table-column prop="gender"
                       label="教练性别">
        <template v-slot="scope">
          {{scope.row.gender==1?"男":"女"}}
        </template>
      </el-table-column>
      <el-table-column prop="phone"
                       label="教练电话"></el-table-column>
      <el-table-column prop="wechat"
                       label="教练微信"></el-table-column>
      <el-table-column prop="schoolName"
                       label="驾校名称"></el-table-column>
      <el-table-column prop
                       label="操作">
        <template v-slot="scope">
          <el-button size="mini"
                     type="primary"
                     @click="getDetail(scope.row)">详情</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog title="教练详情"
               :visible.sync="coachDetailVisible"
               width="80%"
               center>
      <el-descriptions :border="true">
        <el-descriptions-item label="教练名称">
          <el-tag size="small">{{newObj.name}}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="教练性别">{{newObj.gender==1?"男":"女"}}</el-descriptions-item>
        <el-descriptions-item label="教练电话">{{newObj.phone}}</el-descriptions-item>
        <el-descriptions-item label="教练微信">{{newObj.wechat}}</el-descriptions-item>
        <el-descriptions-item label="教练籍贯">{{newObj.nativePlace}}</el-descriptions-item>
        <el-descriptions-item label="教练生日">{{newObj.birthday}}</el-descriptions-item>
        <el-descriptions-item label="居住地址">{{newObj.province}}{{newObj.city}}{{newObj.area}}{{newObj.address}}</el-descriptions-item>
        <el-descriptions-item label="驾校名称">{{newObj.schoolName}}</el-descriptions-item>
        <el-descriptions-item label="执教年限">{{newObj.teachYears}}年</el-descriptions-item>
        <el-descriptions-item label="培训证件">
          <div v-for="(license,index) in newObj.licenseType"
               :key="index">
            <el-tag size="small">{{license}}证</el-tag>
          </div>
        </el-descriptions-item>
        <el-descriptions-item label="车辆品牌">{{newObj.carBrand}}</el-descriptions-item>
        <el-descriptions-item label="变速器类型">{{newObj.transType==1?"手动":"自动"}}档</el-descriptions-item>
        <el-descriptions-item label="场地地址">
          <div v-for="(address,index) in newObj.fieldAddress"
               :key="index">{{index+1}}、{{address}}</div>
        </el-descriptions-item>

        <el-descriptions-item v-for="(item,index) in newObj.licenses"
                              :key="index"
                              :label="item.licenseType+'价格组成'">
          挂牌价组成：{{item.listRemarks}}
          <el-image v-if="item.generalList"
                    :src="item.generalList"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="[item.generalList]"></el-image>
          <el-divider></el-divider>
          合作价组成：{{item.cooperateRemarks}}
          <el-image v-if="item.generalCooperate"
                    :src="item.generalCooperate"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="[item.generalCooperate]"></el-image>
          <el-divider></el-divider>
          <el-tooltip v-if="currentUser.roleType!='guest'"
                      class="item"
                      effect="dark"
                      :content="item.licenseType+'挂牌价 : ￥'+item.listPrice+'，'+item.licenseType+'合作价 : ￥'+item.cooperatePrice"
                      placement="top-start">
            <i class="el-icon-s-opportunity"></i>
          </el-tooltip>
        </el-descriptions-item>

        <el-descriptions-item label="接送范围"
                              span="2">{{newObj.pickupRange}}</el-descriptions-item>
        <el-descriptions-item label="教练照片">
          <el-image v-for="(src,index) in newObj.coachImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.coachImgs"></el-image>
        </el-descriptions-item>
        <el-descriptions-item label="教练证照片">
          <el-image v-for="(src,index) in newObj.coachCardImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.coachCardImgs"></el-image>
        </el-descriptions-item>
        <el-descriptions-item label="短视频介绍">
          <video v-for="(src,index) in newObj.shortVideo"
                 :key="index"
                 style="width:100px;"
                 :src="src"
                 controls>

          </video>
        </el-descriptions-item>
        <el-descriptions-item label="特殊记忆点照片">
          <el-image v-for="(src,index) in newObj.specialMemoImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.specialMemoImgs"></el-image>
        </el-descriptions-item>
        <el-descriptions-item label="教练合同">
          <el-image v-for="(src,index) in newObj.contractImgs"
                    :key="index"
                    :src="src"
                    style="width:100px;"
                    fit="scale-down"
                    lazy
                    :preview-src-list="newObj.contractImgs"></el-image>
        </el-descriptions-item>
      </el-descriptions>
    </el-dialog>

    <el-pagination background
                   layout="prev, sizes,pager, next, jumper"
                   :total="total"
                   @current-change="handleCurrentChange"
                   @size-change="handleSizeChange"
                   :page-sizes="[5, 10, 15, 20]"
                   :page-size="pageSize"></el-pagination>
  </div>
</template>
<script>
export default {
  inject: ['reload'],
  data: function () {
    let currentUser = this.$store.getters['LoginModule/getCurrentUser']
    return {
      currentUser,
      coachs: [],
      newObj: {},
      pageSize: 5,
      coachDetailVisible: false,
      total: 0,
    }
  },
  async created() {
    this.handleCurrentChange(1)
  },
  methods: {
    handleCurrentChange: async function (val) {
      const { data } = await this.$http.post(`/coach/getCoachs`, {
        pageNum: val,
        pageSize: this.pageSize,
        isValid: 4,
      })
      if (data.code == 1) {
        this.coachs = data.object.list
        this.coachs.forEach((coach) => {
          coach.fieldAddress = JSON.parse(coach.fieldAddress)
          coach.coachImgs = JSON.parse(coach.coachImgs)
          coach.coachCardImgs = JSON.parse(coach.coachCardImgs)
          coach.shortVideo = JSON.parse(coach.shortVideo)
          coach.specialMemoImgs = JSON.parse(coach.specialMemoImgs)
          coach.contractImgs = JSON.parse(coach.contractImgs)
          //   coach.generalList = JSON.parse(coach.generalList)
          //   coach.generalCooperate = JSON.parse(coach.generalCooperate)
        })
        this.total = data.object.total
      } else {
        this.$message({
          message: data.message,
          type: 'error',
        })
      }
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.handleCurrentChange(1)
    },
    getDetail: async function (obj) {
      this.newObj = obj
      if (typeof obj.licenseType === 'string') {
        this.newObj.licenseType = JSON.parse(obj.licenseType)
      }

      const { data } = await this.$http.get(
        `/coach/getCoachLicenses?coachId=${this.newObj.id}`
      )
      if (data.code == 1) {
        this.newObj.licenses = data.object
      } else {
        this.$message({
          message: data.message,
          type: 'error',
        })
      }

      this.coachDetailVisible = true
    },
  },
}
</script>
<style>
.el-form-item.show-pic .el-image {
  margin: 0 10px;
}
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 100%;
}
</style>