<template>
  <div>提交成功，已进入审核流程</div>
</template>

<script>
export default {
  data: function () {
    return {}
  },
  created: async function () {
    let coach = this.$store.getters['CoachModule/getNewCoach']
    let currentUser = this.$store.getters['LoginModule/getCurrentUser']
    coach.declareId = currentUser.id
    coach.declareName = currentUser.username
    const { data } = await this.$http.post(`/coach/addCoach`, coach)
    if (data.code == 1) {
      this.$message.success('创建成功，已进入审核流程')
    } else {
      this.$message.error('提交失败，请联系系统管理员')
    }
  },
}
</script>