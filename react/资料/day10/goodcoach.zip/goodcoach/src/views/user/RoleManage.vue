<template>
  <el-container>
    <el-header>
      <el-row>
        <el-button type="primary"
                   @click="addRole">添加角色</el-button>
      </el-row>
    </el-header>
    <el-main>
      <div>
        <el-table :data="roles"
                  stripe>
          <!-- <el-table-column prop="code" label="角色代码"></el-table-column> -->
          <el-table-column prop="name"
                           label="角色名称">
          </el-table-column>
          <el-table-column prop="type"
                           label="类型">
            <template v-slot="scope">
              <el-tag size="small"
                      v-if="scope.row.type=='guest'">来宾用户</el-tag>
              <el-tag size="small"
                      v-if="scope.row.type=='user'">业务用户</el-tag>
              <el-tag size="small"
                      v-else-if="scope.row.type=='system'">系统用户</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="createDate"
                           label="创建时间"></el-table-column>
          <el-table-column prop="updateDate"
                           label="修改时间"></el-table-column>

          <el-table-column prop
                           label="操作">
            <template v-slot="scope">
              <el-button type="primary"
                         @click="grantRole(scope.row)">授权</el-button>
              <el-button type="danger"
                         @click="delRole(scope.row.id)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>

        <el-pagination background
                       layout="prev, pager, next"
                       :total="total"></el-pagination>

        <el-dialog title="角色授权"
                   :visible.sync="centerDialogVisible"
                   width="80%"
                   center>
          <el-descriptions :border="true">
            <el-descriptions-item label="角色名称">
              <el-tag size="small">{{newObj.name}}</el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="角色代码">{{newObj.code}}</el-descriptions-item>
            <el-descriptions-item label="角色类型">{{newObj.gender=='system'?"系统用户":"管理员"}}</el-descriptions-item>
          </el-descriptions>

          <el-tree :data="menus"
                   show-checkbox
                   node-key="id"
                   ref="tree"
                   :default-expanded-keys="menus"
                   :default-checked-keys="checkedKeys"
                   :props="defaultProps">
          </el-tree>

          <span slot="footer"
                class="dialog-footer">
            <el-button type="danger"
                       @click="cancel()">取 消</el-button>
            <el-button type="primary"
                       @click="submit()">提 交</el-button>
          </span>
        </el-dialog>

        <el-dialog title="创建角色"
                   :visible.sync="addRoleVisible"
                   width="20%"
                   center>
          <el-form ref="form"
                   :model="newRole"
                   label-width="80px">
            <el-form-item label="角色名称">
              <el-input v-model="newRole.name"
                        placeholder="示例: 管理员"></el-input>
            </el-form-item>
            <el-form-item label="角色代码">
              <el-select v-model="newRole.code"
                         placeholder="请选择">
                <el-option label="系统管理员"
                           value="admin">
                </el-option>
                <el-option label="总经理"
                           value=3>
                </el-option>
                <el-option label="副总经理"
                           value=2>
                </el-option>
                <el-option label="经理"
                           value=1>
                </el-option>
                <el-option label="客服"
                           value=0>
                </el-option>
                <el-option label="商务"
                           value=0>
                </el-option>
                <el-option label="来宾"
                           value=0>
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="角色类型">
              <el-select v-model="newRole.type"
                         placeholder="请选择">
                <el-option label="系统角色"
                           value="system">
                </el-option>
                <el-option label="用户角色"
                           value="user">
                </el-option>
                <el-option label="来宾角色"
                           value="guest">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button type="primary"
                         @click="submitRole">立即创建</el-button>
              <el-button @click="cancel()">取消</el-button>
            </el-form-item>
          </el-form>
        </el-dialog>
      </div>
    </el-main>
  </el-container>
</template>
<script>
export default {
  inject: ['reload'],
  data: function () {
    return {
      roles: [],
      total: 0,
      centerDialogVisible: false,
      addRoleVisible: false,
      newObj: {},
      menus: [],
      defaultProps: {
        children: 'children',
        label: 'name',
      },
      newRole: {},
      checkedKeys: [],
    }
  },
  async created() {
    const { data } = await this.$http.get(
      `/sysUser/getAllRoles?pageNum=1&pageSize=10`
    )

    if (data.code == 1) {
      this.roles = data.object.list
      this.total = data.object.total
    } else {
      this.$message({
        message: data.message,
        type: 'error',
      })
    }
  },
  methods: {
    grantRole: async function (obj) {
      const { data: AllResources } = await this.$http.get(
        `/sysUser/getAllResources`
      )
      if (AllResources.code == 1) {
        this.menus = AllResources.object
      } else {
        this.$message({
          message: AllResources.message,
          type: 'error',
        })
      }
      this.newObj = obj
      this.centerDialogVisible = true

      const { data: RoleResources } = await this.$http.get(
        `/sysUser/getRoleResources?roleId=${obj.id}`
      )
      this.checkedKeys = RoleResources.object
    },
    submit: async function () {
      const { data } = await this.$http.put(`/sysUser/grantRole`, {
        roleId: this.newObj.id,
        menuIds: [
          ...this.$refs.tree.getCheckedKeys(),
          ...this.$refs.tree.getHalfCheckedKeys(),
        ],
      })
      if (data.code == 1) {
        this.$message.success('授权成功')
        this.cancel()
        this.reload()
      }
    },
    cancel: function () {
      this.newObj = {}
      // centerDialogVisible 角色授权
      this.centerDialogVisible = false
      // addRoleVisible 创建角色
      this.addRoleVisible = false
    },
    delRole: function (roleId) {
      this.$confirm('此操作将永久删除该角色, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(async () => {
          const { data } = await this.$http.delete(
            `/sysUser/delRole?roleId=${roleId}`
          )
          if (data.code == 1) {
            this.$message.success('删除成功')
            this.reload()
          }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    addRole: async function () {
      this.addRoleVisible = true
    },
    submitRole: async function () {
      const { data } = await this.$http.put(`/sysUser/addRole`, this.newRole)
      if (data.code == 1) {
        this.$message.success('新增成功')
      } else {
        this.$message({
          message: data.message,
          type: 'error',
        })
      }
      this.newUser = {}
      this.addUserVisible = false
      this.reload()
    },
  },
}
</script>
<style scoped>
</style>