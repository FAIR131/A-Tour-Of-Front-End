<template>
  <el-container>
    <el-header>
      <el-row>
        <el-button type="primary"
                   @click="addUser">添加用户</el-button>
      </el-row>
    </el-header>
    <el-main>
      <div>
        <el-table :data="users"
                  stripe>
          <el-table-column prop="nickName"
                           label="名称"></el-table-column>
          <el-table-column prop="avatarUrl"
                           label="头像">
            <template v-slot="scope">
              <el-image :src="scope.row.avatarUrl"
                        style="width:50px;height:50px;"></el-image>
            </template>
          </el-table-column>
          <el-table-column prop="phone"
                           label="手机号"></el-table-column>
          <el-table-column prop="createDate"
                           label="创建时间"></el-table-column>
          <el-table-column prop="updateDate"
                           label="修改时间"></el-table-column>
          <el-table-column prop="isValid"
                           label="状态">
            <template v-slot="scope">
              <el-tag size="small">{{scope.row.id==0?'无效':'有效'}}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop
                           label="操作">
            <template v-slot="scope">
              <el-button type="primary"
                         @click="grantUser(scope.row)">授权</el-button>
              <el-button type="danger"
                         @click="delUser(scope.row.id)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>

        <el-pagination background
                       layout="prev, pager, next"
                       :total="total"></el-pagination>

        <el-dialog title="用户授权"
                   :visible.sync="centerDialogVisible"
                   width="80%"
                   center>
          <el-descriptions :border="true">
            <el-descriptions-item label="用户名称">
              <el-tag size="small">{{newObj.nickName}}</el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="手机号">{{newObj.phone}}</el-descriptions-item>
            <el-descriptions-item label="状态">{{newObj.isValid=='1'?"有效":"无效"}}</el-descriptions-item>
          </el-descriptions>

          <el-checkbox-group v-model="checkedKeys">
            <el-checkbox v-for="(role,index) in roles"
                         :key="index"
                         :label="role.id">{{role.name}}</el-checkbox>
          </el-checkbox-group>

          <span slot="footer"
                class="dialog-footer">
            <el-button type="danger"
                       @click="cancel()">取 消</el-button>
            <el-button type="primary"
                       @click="submit()">提 交</el-button>
          </span>
        </el-dialog>

        <el-dialog title="创建用户"
                   :visible.sync="addUserVisible"
                   width="20%"
                   center>
          <el-form ref="form"
                   :model="newUser"
                   label-width="80px">
            <el-form-item label="账号">
              <el-input v-model="newUser.username"
                        placeholder="示例: zhangsan"></el-input>
            </el-form-item>
            <el-form-item label="密码">
              <el-input v-model="newUser.password"
                        placeholder="示例: 123456"></el-input>
            </el-form-item>
            <el-form-item label="昵称">
              <el-input v-model="newUser.nickName"
                        placeholder="示例: 张三"></el-input>
            </el-form-item>
            <el-form-item label="手机号">
              <el-input v-model="newUser.phone"
                        placeholder="示例: 13838385438"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button type="primary"
                         @click="submitUser">立即创建</el-button>
              <el-button @click="cancel()">取消</el-button>
            </el-form-item>
          </el-form>
        </el-dialog>
      </div>
    </el-main>
  </el-container>
</template>
<script>
export default {
  inject: ['reload'],
  data: function () {
    return {
      users: [],
      roles: [],
      total: 0,
      newObj: {},
      centerDialogVisible: false,
      addUserVisible: false,
      newUser: {},
      checkedKeys: [],
    }
  },
  async created() {
    const { data } = await this.$http.get(
      `/sysUser/getAllUsers?pageNum=1&pageSize=10`
    )

    if (data.code == 1) {
      this.users = data.object.list
      this.total = data.object.total
    } else {
      this.$message({
        message: data.message,
        type: 'error',
      })
    }
  },
  methods: {
    grantUser: async function (obj) {
      const { data: AllRoles } = await this.$http.get(
        `/sysUser/getAllRoles?pageNum=1&pageSize=10`
      )

      if (AllRoles.code == 1) {
        this.roles = AllRoles.object.list
      } else {
        this.$message({
          message: AllRoles.message,
          type: 'error',
        })
      }

      this.newObj = obj
      this.centerDialogVisible = true

      const { data: UserRoles } = await this.$http.get(
        `/sysUser/getUserRoles?userId=${obj.id}`
      )
      this.checkedKeys = UserRoles.object
    },
    submit: async function () {
      const { data } = await this.$http.put(`/sysUser/grantUser`, {
        userId: this.newObj.id,
        roleIds: this.checkedKeys,
      })
      if (data.code == 1) {
        this.$message.success('授权成功')
        this.cancel()
        this.reload()
      }
    },
    cancel: function () {
      this.checkedKeys = []
      this.newObj = {}
      // 用户授权
      this.centerDialogVisible = false
      // 创建用户
      this.addUserVisible = false
    },
    delUser: async function (userId) {
      this.$confirm('此操作将永久删除该用户, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(async () => {
          const { data } = await this.$http.delete(
            `/sysUser/delUser?userId=${userId}`
          )
          if (data.code == 1) {
            this.$message.success('删除成功')
            this.reload()
          }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    addUser: async function () {
      this.addUserVisible = true
    },
    submitUser: async function () {
      const { data } = await this.$http.put(`/sysUser/addUser`, this.newUser)
      if (data.code == 1) {
        this.$message.success('新增成功')
      } else {
        this.$message({
          message: data.message,
          type: 'error',
        })
      }
      this.newUser = {}
      this.addUserVisible = false
      this.reload()
    },
  },
}
</script>
<style scoped>
</style>